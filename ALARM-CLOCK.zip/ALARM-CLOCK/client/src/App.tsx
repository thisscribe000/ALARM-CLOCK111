import { useEffect } from "react";
import { Switch, Route, useLocation } from "wouter";
import { queryClient } from "./lib/queryClient";
import { QueryClientProvider } from "@tanstack/react-query";
import { Toaster } from "@/components/ui/toaster";
import { TooltipProvider } from "@/components/ui/tooltip";
import { alarmScheduler } from "@/lib/alarmScheduler";
import { applyTheme, getSettings } from "@/lib/settingsStore";
import Alarms from "@/pages/alarms";
import EditAlarm from "@/pages/edit-alarm";
import AlarmRingingPage from "@/pages/alarm-ringing";
import SettingsPage from "@/pages/settings";
import NotFound from "@/pages/not-found";

function Router() {
  return (
    <Switch>
      <Route path="/" component={Alarms} />
      <Route path="/alarm/:id" component={EditAlarm} />
      <Route path="/ringing/:id" component={AlarmRingingPage} />
      <Route path="/settings" component={SettingsPage} />
      <Route component={NotFound} />
    </Switch>
  );
}

function App() {
  const [, setLocation] = useLocation();

  useEffect(() => {
    // Apply saved theme on app load
    const settings = getSettings();
    applyTheme(settings.theme);

    // Start the alarm scheduler when app loads
    alarmScheduler.start((alarmId) => {
      // When an alarm triggers, navigate to the ringing page
      console.log("📢 Alarm triggered, navigating to ringing page");
      setLocation(`/ringing/${alarmId}`);
    });

    // Stop scheduler when app unmounts
    return () => {
      alarmScheduler.stop();
    };
  }, [setLocation]);

  return (
    <QueryClientProvider client={queryClient}>
      <TooltipProvider>
        <div className="min-h-screen w-full flex items-center justify-center bg-background p-0 sm:p-4">
          <div className="w-full sm:max-w-[428px] h-screen sm:h-[calc(100vh-2rem)] sm:min-h-[600px] bg-card sm:rounded-2xl sm:shadow-xl overflow-hidden flex flex-col">
            <Router />
          </div>
        </div>
        <Toaster />
      </TooltipProvider>
    </QueryClientProvider>
  );
}

export default App;
