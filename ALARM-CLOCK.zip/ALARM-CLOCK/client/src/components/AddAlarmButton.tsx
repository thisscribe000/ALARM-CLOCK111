import { Plus } from "lucide-react";

interface AddAlarmButtonProps {
  onClick: () => void;
}

export default function AddAlarmButton({ onClick }: AddAlarmButtonProps) {
  return (
    <div className="flex flex-col items-center justify-center py-8">
      <button
        onClick={onClick}
        className="w-16 h-16 rounded-full bg-primary text-primary-foreground flex items-center justify-center hover-elevate active-elevate-2 transition-all"
        data-testid="button-add-alarm"
      >
        <Plus className="w-8 h-8" />
      </button>
      <p className="mt-4 text-sm font-medium text-primary">Add new</p>
    </div>
  );
}
