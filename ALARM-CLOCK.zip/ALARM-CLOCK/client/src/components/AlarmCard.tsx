import { Switch } from "@/components/ui/switch";
import { Badge } from "@/components/ui/badge";

interface AlarmCardProps {
  time: string;
  label: string;
  isActive: boolean;
  days: string[];
  isHighlighted?: boolean;
  onToggle: () => void;
  onClick: () => void;
  subtitle?: string; // Added subtitle prop
}

export default function AlarmCard({
  time,
  label,
  isActive,
  days,
  isHighlighted = false,
  onToggle,
  onClick,
  subtitle, // Destructure subtitle
}: AlarmCardProps) {
  const dayMap: Record<string, string> = {
    "Mon": "M",
    "Tues": "T",
    "Wed": "W",
    "Thur": "T",
    "Fri": "F",
    "Sat": "S",
    "Sun": "S"
  };
  
  const activeDays = ["Mon", "Tues", "Wed", "Thur", "Fri", "Sat", "Sun"];

  return (
    <div
      className={`rounded-2xl p-6 cursor-pointer transition-colors ${
        isHighlighted
          ? "bg-gradient-to-br from-purple-500 to-purple-600 text-white"
          : "bg-card border border-card-border hover-elevate"
      }`}
      onClick={onClick}
      data-testid={`alarm-card-${time}`}
    >
      <div className="flex items-start justify-between mb-4">
        <div className="flex-1">
          <p
            className={`text-sm font-medium mb-2 ${
              isHighlighted ? "text-white/80" : "text-muted-foreground"
            }`}
          >
            {label}
          </p>
          <h2
            className={`text-4xl font-bold ${
              isHighlighted ? "text-white" : "text-foreground"
            }`}
          >
            {time}
          </h2>
          {subtitle && isActive && ( // Conditionally render subtitle
            <div className={`text-xs font-medium mt-1 ${
              isHighlighted ? "text-white" : "text-primary"
            }`}>
              {subtitle}
            </div>
          )}
        </div>
        <Switch
          checked={isActive}
          onCheckedChange={(checked) => {
            onToggle();
          }}
          onClick={(e) => e.stopPropagation()}
          data-testid={`switch-alarm-${time}`}
          className={isHighlighted ? "data-[state=checked]:bg-white/30" : ""}
        />
      </div>

      <div className="flex gap-2">
        {activeDays.map((day) => (
          <Badge
            key={day}
            variant="secondary"
            className={`text-xs px-2.5 py-1 font-semibold ${
              isHighlighted
                ? days.includes(day)
                  ? "bg-white/40 text-white border-white/50"
                  : "bg-white/10 text-white/50 border-white/20"
                : days.includes(day)
                ? "bg-primary text-primary-foreground"
                : "bg-muted text-muted-foreground"
            }`}
            data-testid={`badge-${day}`}
          >
            {dayMap[day]}
          </Badge>
        ))}
      </div>
    </div>
  );
}