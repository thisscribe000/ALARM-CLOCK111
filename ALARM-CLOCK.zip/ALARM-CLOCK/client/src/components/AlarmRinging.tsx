import { Button } from "@/components/ui/button";
import { Volume2, Clock } from "lucide-react";

interface AlarmRingingProps {
  time: string;
  label: string;
  snoozeDuration: number;
  onSnooze: (minutes: number) => void;
  onDismiss: () => void;
}

export default function AlarmRinging({
  time,
  label,
  snoozeDuration,
  onSnooze,
  onDismiss,
}: AlarmRingingProps) {
  return (
    <div className="fixed inset-0 bg-gradient-to-br from-purple-500 to-purple-700 z-50 flex flex-col items-center justify-center p-6 text-white">
      {/* Animated Icon */}
      <div className="mb-8 animate-pulse">
        <div className="relative">
          <Clock className="w-24 h-24" strokeWidth={1.5} />
          <div className="absolute -top-2 -right-2">
            <Volume2 className="w-12 h-12 animate-bounce" />
          </div>
        </div>
      </div>

      {/* Time Display */}
      <div className="text-center mb-4">
        <h1 className="text-7xl font-bold mb-2 tracking-tight" data-testid="text-alarm-time">
          {time}
        </h1>
        <p className="text-2xl font-medium opacity-90" data-testid="text-alarm-label">
          {label}
        </p>
      </div>

      {/* Snooze Button */}
      <div className="w-full max-w-sm mt-12 mb-6">
        <button
          onClick={() => onSnooze(snoozeDuration)}
          className="w-full bg-white/20 hover:bg-white/30 active:bg-white/40 backdrop-blur-sm border border-white/30 rounded-lg py-4 px-6 text-lg font-semibold transition-all"
          data-testid={`button-snooze-${snoozeDuration}`}
        >
          Snooze {snoozeDuration} min
        </button>
      </div>

      {/* Dismiss Button */}
      <Button
        size="lg"
        className="w-full max-w-sm h-16 bg-white text-purple-600 hover:bg-white/90 text-lg font-bold shadow-lg"
        onClick={onDismiss}
        data-testid="button-dismiss"
      >
        Dismiss
      </Button>

      {/* Subtle instruction */}
      <p className="text-xs text-white/60 mt-6 text-center">
        Swipe or tap dismiss to turn off alarm
      </p>
    </div>
  );
}
