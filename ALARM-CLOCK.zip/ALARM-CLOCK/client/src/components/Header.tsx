import { ChevronLeft } from "lucide-react";
import { Button } from "@/components/ui/button";

interface HeaderProps {
  title: string;
  onBack?: () => void;
  action?: React.ReactNode;
}

export default function Header({ title, onBack, action }: HeaderProps) {
  return (
    <header className="sticky top-0 z-50 bg-card border-b border-card-border px-4 h-16 flex items-center justify-between">
      <div className="flex items-center gap-2">
        {onBack && (
          <Button
            variant="ghost"
            size="icon"
            onClick={onBack}
            data-testid="button-back"
          >
            <ChevronLeft className="w-5 h-5" />
          </Button>
        )}
        <h1 className="text-xl font-semibold text-foreground">{title}</h1>
      </div>
      {action && <div>{action}</div>}
    </header>
  );
}
