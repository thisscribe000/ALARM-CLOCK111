import { useState, useEffect } from "react";
import { X, Circle } from "lucide-react";
import { Button } from "@/components/ui/button";
import { getSettings } from "@/lib/settingsStore";

interface TicTacToeModalProps {
  onComplete: () => void;
}

type Player = "X" | "O" | null;
type Board = Player[];

export default function TicTacToeModal({ onComplete }: TicTacToeModalProps) {
  const [board, setBoard] = useState<Board>(Array(9).fill(null));
  const [isPlayerTurn, setIsPlayerTurn] = useState(true);
  const [winner, setWinner] = useState<Player | "draw" | null>(null);
  const [winningLine, setWinningLine] = useState<number[]>([]);
  const settings = getSettings();

  const winPatterns = [
    [0, 1, 2], [3, 4, 5], [6, 7, 8], // rows
    [0, 3, 6], [1, 4, 7], [2, 5, 8], // columns
    [0, 4, 8], [2, 4, 6] // diagonals
  ];

  const checkWinner = (currentBoard: Board): { winner: Player | "draw" | null; line: number[] } => {
    // Check for winner
    for (const pattern of winPatterns) {
      const [a, b, c] = pattern;
      if (
        currentBoard[a] &&
        currentBoard[a] === currentBoard[b] &&
        currentBoard[a] === currentBoard[c]
      ) {
        return { winner: currentBoard[a], line: pattern };
      }
    }

    // Check for draw
    if (currentBoard.every((cell) => cell !== null)) {
      return { winner: "draw", line: [] };
    }

    return { winner: null, line: [] };
  };

  const getAIMove = (currentBoard: Board): number => {
    const emptySpots = currentBoard
      .map((cell, index) => (cell === null ? index : null))
      .filter((index) => index !== null) as number[];

    if (emptySpots.length === 0) return -1;

    const difficulty = settings.ticTacToeDifficulty;

    // Easy: Random move
    if (difficulty === "easy") {
      return emptySpots[Math.floor(Math.random() * emptySpots.length)];
    }

    // Medium: 50% chance of smart move, 50% random
    if (difficulty === "medium" && Math.random() < 0.5) {
      return emptySpots[Math.floor(Math.random() * emptySpots.length)];
    }

    // Hard (or medium 50% of the time): Minimax algorithm
    const minimax = (board: Board, depth: number, isMaximizing: boolean): number => {
      const result = checkWinner(board);
      if (result.winner === "O") return 10 - depth;
      if (result.winner === "X") return depth - 10;
      if (result.winner === "draw") return 0;

      if (isMaximizing) {
        let bestScore = -Infinity;
        for (let i = 0; i < 9; i++) {
          if (board[i] === null) {
            board[i] = "O";
            const score = minimax(board, depth + 1, false);
            board[i] = null;
            bestScore = Math.max(score, bestScore);
          }
        }
        return bestScore;
      } else {
        let bestScore = Infinity;
        for (let i = 0; i < 9; i++) {
          if (board[i] === null) {
            board[i] = "X";
            const score = minimax(board, depth + 1, true);
            board[i] = null;
            bestScore = Math.min(score, bestScore);
          }
        }
        return bestScore;
      }
    };

    let bestScore = -Infinity;
    let bestMove = emptySpots[0];

    for (const move of emptySpots) {
      const testBoard = [...currentBoard];
      testBoard[move] = "O";
      const score = minimax(testBoard, 0, false);
      if (score > bestScore) {
        bestScore = score;
        bestMove = move;
      }
    }

    return bestMove;
  };


  const makeAIMove = (currentBoard: Board) => {
    const move = getAIMove(currentBoard);

    if (move === -1) return;

    setTimeout(() => {
      const newBoard = [...currentBoard];
      newBoard[move] = "O";
      setBoard(newBoard);

      const result = checkWinner(newBoard);
      if (result.winner) {
        setWinner(result.winner);
        setWinningLine(result.line);
      } else {
        setIsPlayerTurn(true);
      }
    }, 500);
  };

  const handleCellClick = (index: number) => {
    if (board[index] || !isPlayerTurn || winner) return;

    const newBoard = [...board];
    newBoard[index] = "X";
    setBoard(newBoard);

    const result = checkWinner(newBoard);
    if (result.winner) {
      setWinner(result.winner);
      setWinningLine(result.line);
    } else {
      setIsPlayerTurn(false);
      makeAIMove(newBoard);
    }
  };

  const handleComplete = () => {
    console.log("🎮 TicTacToeModal: Dismiss Alarm button clicked");
    console.log("🎮 TicTacToeModal: Calling onComplete callback...");
    onComplete();
  };

  return (
    <div className="fixed inset-0 bg-black/80 z-50 flex items-center justify-center p-6">
      <div className="bg-card rounded-2xl p-6 max-w-md w-full shadow-xl animate-in fade-in zoom-in duration-300">
        <div className="text-center mb-6">
          <h2 className="text-2xl font-bold text-foreground mb-2">
            Play Tic-Tac-Toe to Dismiss
          </h2>
          {winner ? (
            <p className="text-lg font-semibold text-primary">
              {winner === "draw"
                ? "It's a draw!"
                : winner === "X"
                ? "You won! 🎉"
                : "AI won! 🤖"}
            </p>
          ) : (
            <p className="text-muted-foreground">
              {isPlayerTurn ? "Your turn (X)" : "AI thinking... (O)"}
            </p>
          )}
        </div>

        <div className="grid grid-cols-3 gap-3 mb-6">
          {board.map((cell, index) => {
            const isWinningCell = winningLine.includes(index);
            return (
              <button
                key={index}
                onClick={() => handleCellClick(index)}
                disabled={!isPlayerTurn || !!cell || !!winner}
                className={`aspect-square rounded-lg border-2 flex items-center justify-center text-4xl font-bold transition-all ${
                  isWinningCell
                    ? "bg-primary/20 border-primary scale-105"
                    : "border-border hover-elevate active-elevate-2"
                } ${!cell && isPlayerTurn && !winner ? "cursor-pointer" : "cursor-default"}`}
                data-testid={`cell-${index}`}
              >
                {cell === "X" && (
                  <X className="w-12 h-12 text-primary animate-in zoom-in duration-200" strokeWidth={3} />
                )}
                {cell === "O" && (
                  <Circle className="w-12 h-12 text-destructive animate-in zoom-in duration-200" strokeWidth={3} />
                )}
              </button>
            );
          })}
        </div>

        {winner && (
          <Button
            onClick={handleComplete}
            className="w-full h-12 text-lg font-semibold"
            data-testid="button-complete"
          >
            Dismiss Alarm
          </Button>
        )}
      </div>
    </div>
  );
}