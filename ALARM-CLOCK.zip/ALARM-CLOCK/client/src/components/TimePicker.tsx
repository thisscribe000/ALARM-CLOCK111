import { useRef, useEffect, useState } from "react";

interface TimePickerProps {
  value: { hour: number; minute: number; period: "AM" | "PM" };
  onChange: (value: { hour: number; minute: number; period: "AM" | "PM" }) => void;
}

export default function TimePicker({ value, onChange }: TimePickerProps) {
  const hours = Array.from({ length: 12 }, (_, i) => (i === 0 ? 12 : i));
  const minutes = Array.from({ length: 60 }, (_, i) => i);
  const periods = ["AM", "PM"];

  const hourRef = useRef<HTMLDivElement>(null);
  const minuteRef = useRef<HTMLDivElement>(null);
  const periodRef = useRef<HTMLDivElement>(null);

  const [isDragging, setIsDragging] = useState(false);
  const scrollTimeoutRef = useRef<NodeJS.Timeout>();
  const isInitializing = useRef(true);

  // Get actual item height from DOM
  const getItemHeight = (ref: React.RefObject<HTMLDivElement>): number => {
    if (!ref.current) return 56; // fallback
    const firstChild = ref.current.querySelector('div');
    if (!firstChild) return 56;
    return firstChild.getBoundingClientRect().height;
  };

  useEffect(() => {
    isInitializing.current = true;
    
    // Wait for DOM to be ready before measuring
    setTimeout(() => {
      if (hourRef.current) {
        const itemHeight = getItemHeight(hourRef);
        const hourIndex = value.hour === 12 ? 0 : value.hour;
        hourRef.current.scrollTop = hourIndex * itemHeight;
      }
      if (minuteRef.current) {
        const itemHeight = getItemHeight(minuteRef);
        minuteRef.current.scrollTop = value.minute * itemHeight;
      }
      if (periodRef.current) {
        const itemHeight = getItemHeight(periodRef);
        periodRef.current.scrollTop = value.period === "AM" ? 0 : itemHeight;
      }
      
      setTimeout(() => {
        isInitializing.current = false;
      }, 50);
    }, 0);
  }, []);

  const handleScrollEnd = (
    type: "hour" | "minute" | "period",
    ref: React.RefObject<HTMLDivElement>
  ) => {
    if (isInitializing.current) return;
    
    if (scrollTimeoutRef.current) {
      clearTimeout(scrollTimeoutRef.current);
    }

    scrollTimeoutRef.current = setTimeout(() => {
      if (!ref.current) return;
      
      const scrollTop = ref.current.scrollTop;
      const itemHeight = getItemHeight(ref);
      const index = Math.round(scrollTop / itemHeight);
      const targetScroll = index * itemHeight;
      
      // Snap to exact position
      ref.current.scrollTop = targetScroll;

      // Update the value based on final scroll position
      if (type === "hour") {
        const newHour = hours[index] || value.hour;
        if (newHour !== value.hour) {
          onChange({ ...value, hour: newHour });
        }
      } else if (type === "minute") {
        const newMinute = minutes[index] !== undefined ? minutes[index] : value.minute;
        if (newMinute !== value.minute) {
          onChange({ ...value, minute: newMinute });
        }
      } else {
        const newPeriod = periods[index] as "AM" | "PM";
        if (newPeriod !== value.period) {
          onChange({ ...value, period: newPeriod });
        }
      }
    }, 150);
  };

  const handleScroll = (
    type: "hour" | "minute" | "period",
    e: React.UIEvent<HTMLDivElement>
  ) => {
    handleScrollEnd(type, type === "hour" ? hourRef : type === "minute" ? minuteRef : periodRef);
  };

  return (
    <div className="flex items-center justify-center gap-4 my-8">
      <div className="relative h-48 overflow-hidden">
        <div className="absolute inset-x-0 top-1/2 -translate-y-1/2 h-14 border-y-2 border-primary/20 pointer-events-none z-10" />
        <div
          ref={hourRef}
          className="h-full overflow-y-scroll snap-y snap-mandatory scrollbar-hide py-20"
          onScroll={(e) => handleScroll("hour", e)}
          data-testid="picker-hour"
        >
          {hours.map((hour) => (
            <div
              key={hour}
              className="h-14 flex items-center justify-center text-3xl font-semibold snap-center text-foreground/40"
              style={{
                opacity:
                  hour === value.hour
                    ? 1
                    : Math.max(0.3, 1 - Math.abs(hour - value.hour) * 0.3),
              }}
            >
              {hour.toString().padStart(2, "0")}
            </div>
          ))}
        </div>
      </div>

      <div className="text-3xl font-bold text-foreground">:</div>

      <div className="relative h-48 overflow-hidden">
        <div className="absolute inset-x-0 top-1/2 -translate-y-1/2 h-14 border-y-2 border-primary/20 pointer-events-none z-10" />
        <div
          ref={minuteRef}
          className="h-full overflow-y-scroll snap-y snap-mandatory scrollbar-hide py-20"
          onScroll={(e) => handleScroll("minute", e)}
          data-testid="picker-minute"
        >
          {minutes.map((minute) => (
            <div
              key={minute}
              className="h-14 flex items-center justify-center text-3xl font-semibold snap-center text-foreground/40"
              style={{
                opacity:
                  minute === value.minute
                    ? 1
                    : Math.max(0.3, 1 - Math.abs(minute - value.minute) * 0.05),
              }}
            >
              {minute.toString().padStart(2, "0")}
            </div>
          ))}
        </div>
      </div>

      <div className="relative h-48 overflow-hidden">
        <div className="absolute inset-x-0 top-1/2 -translate-y-1/2 h-14 border-y-2 border-primary/20 pointer-events-none z-10" />
        <div
          ref={periodRef}
          className="h-full overflow-y-scroll snap-y snap-mandatory scrollbar-hide py-20"
          onScroll={(e) => handleScroll("period", e)}
          data-testid="picker-period"
        >
          {periods.map((period) => (
            <div
              key={period}
              className="h-14 flex items-center justify-center text-3xl font-semibold snap-center text-foreground/40"
              style={{
                opacity: period === value.period ? 1 : 0.3,
              }}
            >
              {period}
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}
