import AddAlarmButton from "../AddAlarmButton";

export default function AddAlarmButtonExample() {
  return (
    <div className="p-4">
      <AddAlarmButton onClick={() => console.log("Add alarm clicked")} />
    </div>
  );
}
