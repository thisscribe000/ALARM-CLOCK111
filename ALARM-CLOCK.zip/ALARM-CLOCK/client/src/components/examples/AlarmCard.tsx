import AlarmCard from "../AlarmCard";
import { useState } from "react";

export default function AlarmCardExample() {
  const [isActive, setIsActive] = useState(true);

  return (
    <div className="p-4 space-y-4">
      <AlarmCard
        time="09:30 AM"
        label="Wake up"
        isActive={isActive}
        days={["Mon", "Tues", "Wed", "Thur", "Fri"]}
        isHighlighted={true}
        onToggle={() => setIsActive(!isActive)}
        onClick={() => console.log("Alarm card clicked")}
      />
      <AlarmCard
        time="01:30 PM"
        label="After lunch pill"
        isActive={false}
        days={["Mon", "Tues", "Wed", "Thur", "Fri"]}
        onToggle={() => console.log("Toggle")}
        onClick={() => console.log("Alarm card clicked")}
      />
    </div>
  );
}
