import AlarmRinging from "../AlarmRinging";

export default function AlarmRingingExample() {
  return (
    <AlarmRinging
      time="09:30 AM"
      label="Wake up"
      snoozeDuration={10}
      onSnooze={(minutes) => console.log("Snoozed for:", minutes)}
      onDismiss={() => console.log("Dismissed")}
    />
  );
}
