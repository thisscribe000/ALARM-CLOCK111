import Header from "../Header";
import { Button } from "@/components/ui/button";

export default function HeaderExample() {
  return (
    <div className="space-y-4">
      <Header title="Alarms" />
      <Header 
        title="Edit alarm" 
        onBack={() => console.log("Back clicked")}
        action={
          <Button variant="ghost" size="sm" data-testid="button-action">
            Done
          </Button>
        }
      />
    </div>
  );
}
