import TicTacToeModal from "../TicTacToeModal";

export default function TicTacToeModalExample() {
  return (
    <TicTacToeModal onComplete={() => console.log("Game completed!")} />
  );
}
