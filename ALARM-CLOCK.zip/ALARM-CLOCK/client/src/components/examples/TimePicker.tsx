import TimePicker from "../TimePicker";
import { useState } from "react";

export default function TimePickerExample() {
  const [time, setTime] = useState({ hour: 3, minute: 30, period: "PM" as "AM" | "PM" });

  return (
    <div className="p-4">
      <TimePicker value={time} onChange={setTime} />
      <p className="text-center text-muted-foreground mt-4">
        Selected: {time.hour.toString().padStart(2, "0")}:{time.minute.toString().padStart(2, "0")} {time.period}
      </p>
    </div>
  );
}
