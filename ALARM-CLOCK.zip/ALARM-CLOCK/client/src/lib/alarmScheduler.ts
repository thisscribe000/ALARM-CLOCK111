import { getAlarms, updateAlarm, type Alarm } from "./alarmStore";

/**
 * Alarm Scheduler Service
 * 
 * This service runs in the background and checks every minute whether any alarms
 * should be triggered. When an alarm's time matches the current time, it triggers
 * the alarm by calling the onAlarmTrigger callback.
 */

interface SnoozeData {
  alarmId: string;
  snoozeUntil: number; // timestamp
  snoozeCount: number;
}

class AlarmScheduler {
  private checkInterval: NodeJS.Timeout | null = null;
  private onAlarmTrigger: ((alarmId: string) => void) | null = null;
  private snoozedAlarms: Map<string, SnoozeData> = new Map();
  private triggeredAlarms: Map<string, number> = new Map(); // Track when alarms were triggered

  /**
   * Start the scheduler
   * @param callback - Function to call when an alarm should trigger (e.g., navigate to ringing page)
   */
  start(callback: (alarmId: string) => void): void {
    console.log("🕐 Alarm scheduler started");
    this.onAlarmTrigger = callback;

    // Check immediately
    this.checkAlarms();

    // Then check every 5 seconds for better responsiveness
    this.checkInterval = setInterval(() => {
      this.checkAlarms();
    }, 5000); // 5 seconds
  }

  /**
   * Stop the scheduler
   */
  stop(): void {
    if (this.checkInterval) {
      clearInterval(this.checkInterval);
      this.checkInterval = null;
      console.log("🛑 Alarm scheduler stopped");
    }
  }

  /**
   * Check if any alarms should be triggered now
   */
  private checkAlarms(): void {
    const now = new Date();
    const currentDay = ["Sun", "Mon", "Tues", "Wed", "Thur", "Fri", "Sat"][now.getDay()];
    const currentHour = now.getHours();
    const currentMinute = now.getMinutes();

    // Check snoozed alarms first
    this.checkSnoozedAlarms(now);

    // Check regular alarms
    const alarms = getAlarms();

    for (const alarm of alarms) {
      // Skip inactive alarms
      if (!alarm.isActive) continue;

      // Skip if already snoozed
      if (this.snoozedAlarms.has(alarm.id)) continue;

      // Skip if already triggered in the last 5 minutes (prevents re-triggering after dismiss)
      const lastTriggered = this.triggeredAlarms.get(alarm.id);
      if (lastTriggered && (Date.now() - lastTriggered) < 300000) { // 5 minutes = 300000ms
        continue;
      }

      // Convert alarm time to 24-hour format
      let alarmHour = alarm.hour;
      if (alarm.period === "PM" && alarm.hour !== 12) {
        alarmHour += 12;
      } else if (alarm.period === "AM" && alarm.hour === 12) {
        alarmHour = 0;
      }

      // Check if time matches
      const timeMatches = alarmHour === currentHour && alarm.minute === currentMinute;

      if (!timeMatches) continue;

      // Check if today is a scheduled day (if days are specified)
      if (alarm.days.length > 0 && !alarm.days.includes(currentDay)) {
        continue;
      }

      // Trigger the alarm!
      console.log("⏰ Triggering alarm:", alarm.label);
      this.triggeredAlarms.set(alarm.id, Date.now());
      this.triggerAlarm(alarm.id);
    }
  }

  /**
   * Check if any snoozed alarms should ring now
   */
  private checkSnoozedAlarms(now: Date): void {
    const currentTime = now.getTime();

    // Convert to array to avoid iterator issues
    const snoozedEntries = Array.from(this.snoozedAlarms.entries());

    for (const [alarmId, snoozeData] of snoozedEntries) {
      if (currentTime >= snoozeData.snoozeUntil) {
        console.log("⏰ Triggering snoozed alarm:", alarmId);
        this.triggerAlarm(alarmId);
        // Remove from snoozed list (it will be added back if snoozed again)
        this.snoozedAlarms.delete(alarmId);
      }
    }
  }

  /**
   * Trigger an alarm (call the callback to show the ringing page)
   */
  private triggerAlarm(alarmId: string): void {
    if (this.onAlarmTrigger) {
      this.onAlarmTrigger(alarmId);
    }
  }

  /**
   * Snooze an alarm
   * @param alarmId - The alarm to snooze
   * @param minutes - How many minutes to snooze for
   * @returns true if snoozed successfully, false if max snooze count reached
   */
  snooze(alarmId: string, minutes: number): boolean {
    const alarm = getAlarms().find((a) => a.id === alarmId);
    if (!alarm) return false;

    // Check if already snoozed and get current snooze count
    const existingSnooze = this.snoozedAlarms.get(alarmId);
    const currentSnoozeCount = existingSnooze ? existingSnooze.snoozeCount : 0;

    // Check max snooze limit (unless it's "forever")
    if (alarm.maxSnoozeCount !== "forever") {
      const maxCount = parseInt(alarm.maxSnoozeCount);
      if (currentSnoozeCount >= maxCount) {
        console.log("❌ Max snooze count reached for alarm:", alarm.label);
        return false;
      }
    }

    // Calculate snooze time
    const snoozeUntil = Date.now() + minutes * 60 * 1000;

    // Store snooze data
    this.snoozedAlarms.set(alarmId, {
      alarmId,
      snoozeUntil,
      snoozeCount: currentSnoozeCount + 1,
    });

    console.log(
      `💤 Alarm snoozed: ${alarm.label} for ${minutes} minutes (${currentSnoozeCount + 1}/${alarm.maxSnoozeCount})`
    );

    return true;
  }

  /**
   * Get snooze info for an alarm
   */
  getSnoozeInfo(alarmId: string): SnoozeData | null {
    return this.snoozedAlarms.get(alarmId) || null;
  }

  /**
   * Clear snooze for an alarm (when dismissed)
   * Also updates the triggered time to NOW to prevent immediate re-triggering
   * while still allowing the alarm to ring again after the guard period
   */
  clearSnooze(alarmId: string): void {
    console.log("🧹 alarmScheduler.clearSnooze() called for alarm:", alarmId);
    const hadSnooze = this.snoozedAlarms.has(alarmId);
    
    // Clear snooze data
    this.snoozedAlarms.delete(alarmId);
    
    // Update triggered time to NOW to prevent immediate re-trigger
    // The guard period in checkAlarms() will prevent re-triggering
    this.triggeredAlarms.set(alarmId, Date.now());
    
    console.log(`🧹 Cleared snooze: ${hadSnooze}, set trigger guard to prevent re-trigger`);
  }

  /**
   * Get all snoozed alarms
   */
  getSnoozedAlarms(): SnoozeData[] {
    return Array.from(this.snoozedAlarms.values());
  }
}

// Export singleton instance
export const alarmScheduler = new AlarmScheduler();

// Export types
export type { SnoozeData };