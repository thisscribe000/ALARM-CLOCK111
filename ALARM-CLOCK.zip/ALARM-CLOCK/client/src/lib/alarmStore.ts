interface Alarm {
  id: string;
  label: string;
  hour: number;
  minute: number;
  period: "AM" | "PM";
  days: string[];
  isActive: boolean;
  sound: string;
  snooze: string;
  maxSnoozeCount: string;
  requireTicTacToe: boolean;
  nextTrigger?: number;
}

const STORAGE_KEY = "alarms";

export function generateUUID(): string {
  return "xxxxxxxx-xxxx-4xxx-yxxx-xxxxxxxxxxxx".replace(/[xy]/g, (c) => {
    const r = (Math.random() * 16) | 0;
    const v = c === "x" ? r : (r & 0x3) | 0x8;
    return v.toString(16);
  });
}

export function getAlarms(): Alarm[] {
  try {
    const stored = localStorage.getItem(STORAGE_KEY);
    if (!stored) return [];
    const alarms = JSON.parse(stored);
    return alarms.map((alarm: Alarm) => ({
      ...alarm,
      nextTrigger: computeNextTrigger(alarm),
    }));
  } catch (error) {
    console.error("Failed to load alarms:", error);
    return [];
  }
}

export function saveAlarm(alarm: Omit<Alarm, "id">): Alarm {
  const newAlarm: Alarm = {
    ...alarm,
    id: generateUUID(),
    nextTrigger: computeNextTrigger(alarm as Alarm),
  };

  const alarms = getAlarms();
  alarms.push(newAlarm);
  localStorage.setItem(STORAGE_KEY, JSON.stringify(alarms));
  return newAlarm;
}

export function updateAlarm(id: string, data: Partial<Alarm>): Alarm | null {
  const alarms = getAlarms();
  const index = alarms.findIndex((a) => a.id === id);

  if (index === -1) return null;

  const updatedAlarm: Alarm = {
    ...alarms[index],
    ...data,
    nextTrigger: computeNextTrigger({ ...alarms[index], ...data }),
  };

  alarms[index] = updatedAlarm;
  localStorage.setItem(STORAGE_KEY, JSON.stringify(alarms));
  return updatedAlarm;
}

export function deleteAlarm(id: string): boolean {
  const alarms = getAlarms();
  const filtered = alarms.filter((a) => a.id !== id);

  if (filtered.length === alarms.length) return false;

  localStorage.setItem(STORAGE_KEY, JSON.stringify(filtered));
  return true;
}

export function toggleAlarm(id: string): Alarm | null {
  const alarms = getAlarms();
  const alarm = alarms.find((a) => a.id === id);

  if (!alarm) return null;

  return updateAlarm(id, { isActive: !alarm.isActive });
}

export function computeNextTrigger(alarm: Alarm): number {
  if (!alarm.isActive) return 0;

  const now = new Date();
  const dayMap: { [key: string]: number } = {
    Sun: 0,
    Mon: 1,
    Tues: 2,
    Wed: 3,
    Thur: 4,
    Fri: 5,
    Sat: 6,
  };

  // Convert alarm time to 24-hour format
  let hours = alarm.hour;
  if (alarm.period === "PM" && hours !== 12) hours += 12;
  if (alarm.period === "AM" && hours === 12) hours = 0;

  // If no days selected, treat as one-time alarm for today
  if (alarm.days.length === 0) {
    const trigger = new Date(now);
    trigger.setHours(hours, alarm.minute, 0, 0);
    
    if (trigger.getTime() <= now.getTime()) {
      trigger.setDate(trigger.getDate() + 1);
    }
    
    return trigger.getTime();
  }

  // Find next occurrence
  const currentDay = now.getDay();
  
  let daysUntilNext = Infinity;

  for (const day of alarm.days) {
    const targetDay = dayMap[day];
    let diff = targetDay - currentDay;

    // If the target day is before today in the week, add 7 to get next week
    if (diff < 0) {
      diff += 7;
    } 
    // If it's today, we need to check if the time has passed
    else if (diff === 0) {
      // Create a date object for today at the alarm time
      const todayAlarmTime = new Date(now);
      todayAlarmTime.setHours(hours, alarm.minute, 0, 0);
      
      // If the alarm time for today has already passed, schedule for next week
      if (todayAlarmTime.getTime() <= now.getTime()) {
        diff = 7;
      }
    }

    if (diff < daysUntilNext) {
      daysUntilNext = diff;
    }
  }

  // If no valid day found, something is wrong
  if (daysUntilNext === Infinity) {
    return 0;
  }

  const trigger = new Date(now);
  trigger.setDate(trigger.getDate() + daysUntilNext);
  trigger.setHours(hours, alarm.minute, 0, 0);

  return trigger.getTime();
}

export type { Alarm };
