class AudioService {
  private audio: HTMLAudioElement | null = null;
  private currentSound: string | null = null;

  /**
   * Play a sound file
   * @param url - URL or path to the sound file
   * @param loop - Whether to loop the sound (default: true)
   */
  playSound(url: string, loop: boolean = true): void {
    // Stop any currently playing sound
    this.stopSound();

    try {
      this.audio = new Audio(url);
      this.audio.loop = loop;
      this.currentSound = url;

      // Play the audio
      this.audio.play().catch((error) => {
        console.error("Failed to play sound:", error);
        console.warn("Audio file not found or cannot be played. Using fallback beep.");
        // Fallback: create a beep sound using Web Audio API
        this.playBeepFallback();
      });
    } catch (error) {
      console.error("Error creating audio:", error);
      this.playBeepFallback();
    }
  }

  /**
   * Fallback alarm using Web Audio API (creates a beep sound)
   */
  private playBeepFallback(): void {
    try {
      const audioContext = new (window.AudioContext || (window as any).webkitAudioContext)();
      const oscillator = audioContext.createOscillator();
      const gainNode = audioContext.createGain();

      oscillator.connect(gainNode);
      gainNode.connect(audioContext.destination);

      oscillator.frequency.value = 800; // 800 Hz beep
      oscillator.type = 'sine';

      gainNode.gain.setValueAtTime(0.3, audioContext.currentTime);

      oscillator.start();

      // Create repeating beeps
      const beepInterval = setInterval(() => {
        gainNode.gain.setValueAtTime(0.3, audioContext.currentTime);
        gainNode.gain.exponentialRampToValueAtTime(0.01, audioContext.currentTime + 0.3);
      }, 500);

      // Store reference for cleanup
      (this as any).beepInterval = beepInterval;
      (this as any).audioContext = audioContext;
      (this as any).oscillator = oscillator;
    } catch (error) {
      console.error("Failed to create fallback beep:", error);
    }
  }

  /**
   * Stop the currently playing sound
   */
  stopSound(): void {
    console.log("🔇 audioService.stopSound() called");
    
    if (this.audio) {
      console.log("🔇 Stopping HTML Audio element");
      this.audio.pause();
      this.audio.currentTime = 0;
      this.audio = null;
      this.currentSound = null;
    }

    // Cleanup Web Audio API fallback
    if ((this as any).beepInterval) {
      console.log("🔇 Clearing beep interval");
      clearInterval((this as any).beepInterval);
      (this as any).beepInterval = null;
    }
    if ((this as any).oscillator) {
      console.log("🔇 Stopping oscillator");
      try {
        (this as any).oscillator.stop();
      } catch (e) {
        console.log("🔇 Oscillator already stopped");
      }
      (this as any).oscillator = null;
    }
    if ((this as any).audioContext) {
      console.log("🔇 Closing audio context");
      (this as any).audioContext.close();
      (this as any).audioContext = null;
    }
    
    console.log("✅ Sound stopped successfully");
  }

  /**
   * Get the currently playing sound URL
   */
  getCurrentSound(): string | null {
    return this.currentSound;
  }

  /**
   * Check if a sound is currently playing
   */
  isPlaying(): boolean {
    return this.audio !== null && !this.audio.paused;
  }

  /**
   * Load bundled sounds (predefined alarm sounds)
   * Returns a map of sound names to their URLs
   */
  loadBundledSounds(): Record<string, string> {
    // TODO: Replace with actual sound files in client/src/assets/sounds/
    return {
      default: "/sounds/default-alarm.mp3",
      gentle: "/sounds/gentle-wake.mp3",
      loud: "/sounds/loud-alarm.mp3",
      birdsong: "/sounds/birdsong.mp3",
      chimes: "/sounds/chimes.mp3",
    };
  }

  /**
   * Load a user-uploaded sound file
   * @param file - The File object from an input element
   * @returns Promise that resolves to a data URL
   */
  async loadUserSound(file: File): Promise<string> {
    return new Promise((resolve, reject) => {
      if (!file.type.startsWith("audio/")) {
        reject(new Error("File must be an audio file"));
        return;
      }

      const reader = new FileReader();
      
      reader.onload = (e) => {
        const result = e.target?.result;
        if (typeof result === "string") {
          resolve(result);
        } else {
          reject(new Error("Failed to read file"));
        }
      };

      reader.onerror = () => {
        reject(new Error("Failed to read file"));
      };

      reader.readAsDataURL(file);
    });
  }
}

// Export a singleton instance
export const audioService = new AudioService();

// Export the class for testing purposes
export { AudioService };
