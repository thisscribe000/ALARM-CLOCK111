
interface Settings {
  theme: "light" | "dark" | "system";
  ticTacToeDifficulty: "easy" | "medium" | "hard";
  alarmSoundOption: "default" | "choose" | "custom";
  customSoundUrl?: string;
  use24HourTime: boolean | "system";
}

const SETTINGS_KEY = "app-settings";

const defaultSettings: Settings = {
  theme: "system",
  ticTacToeDifficulty: "medium",
  alarmSoundOption: "default",
  use24HourTime: "system",
};

export function getSettings(): Settings {
  try {
    const stored = localStorage.getItem(SETTINGS_KEY);
    if (!stored) return defaultSettings;
    return { ...defaultSettings, ...JSON.parse(stored) };
  } catch (error) {
    console.error("Failed to load settings:", error);
    return defaultSettings;
  }
}

export function updateSettings(updates: Partial<Settings>): Settings {
  const current = getSettings();
  const updated = { ...current, ...updates };
  localStorage.setItem(SETTINGS_KEY, JSON.stringify(updated));
  
  // Apply theme immediately
  if (updates.theme !== undefined) {
    applyTheme(updates.theme);
  }
  
  return updated;
}

export function applyTheme(theme: "light" | "dark" | "system") {
  const root = document.documentElement;
  
  if (theme === "system") {
    const prefersDark = window.matchMedia("(prefers-color-scheme: dark)").matches;
    root.classList.toggle("dark", prefersDark);
  } else {
    root.classList.toggle("dark", theme === "dark");
  }
}

export function saveFeedback(feedback: string): void {
  const feedbackKey = "user-feedback";
  const existing = localStorage.getItem(feedbackKey);
  const feedbackList = existing ? JSON.parse(existing) : [];
  
  feedbackList.push({
    feedback,
    timestamp: new Date().toISOString(),
  });
  
  localStorage.setItem(feedbackKey, JSON.stringify(feedbackList));
}

export type { Settings };
