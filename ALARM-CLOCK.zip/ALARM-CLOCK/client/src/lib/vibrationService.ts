
class VibrationService {
  /**
   * Vibrate the device (mobile only)
   * @param pattern - Array of vibration durations in ms [vibrate, pause, vibrate, ...]
   */
  vibrate(pattern: number[] = [200, 100, 200]): void {
    if ('vibrate' in navigator) {
      navigator.vibrate(pattern);
    }
  }

  /**
   * Continuous alarm vibration pattern
   */
  startAlarmVibration(): void {
    if ('vibrate' in navigator) {
      // Long vibration pattern: vibrate for 500ms, pause 500ms, repeat
      this.vibrate([500, 500, 500, 500, 500, 500]);
    }
  }

  /**
   * Stop all vibrations
   */
  stopVibration(): void {
    if ('vibrate' in navigator) {
      navigator.vibrate(0);
    }
  }
}

// Export singleton instance
export const vibrationService = new VibrationService();
