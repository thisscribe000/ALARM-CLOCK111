import { useState, useEffect } from "react";
import { useLocation, useRoute } from "wouter";
import AlarmRinging from "@/components/AlarmRinging";
import TicTacToeModal from "@/components/TicTacToeModal";
import { getAlarms, updateAlarm } from "@/lib/alarmStore";
import { audioService } from "@/lib/audioService";
import { alarmScheduler } from "@/lib/alarmScheduler";
import { useToast } from "@/hooks/use-toast";

export default function AlarmRingingPage() {
  const [, setLocation] = useLocation();
  const [, params] = useRoute("/ringing/:id");
  const { toast } = useToast();
  const [showTicTacToe, setShowTicTacToe] = useState(false);
  
  // Load alarm immediately (not in useEffect)
  const currentAlarm = getAlarms().find((a) => a.id === params?.id);

  // Play sound and vibration
  useEffect(() => {
    if (!currentAlarm) {
      console.log("❌ Alarm not found, redirecting to home");
      setLocation("/");
      return;
    }

    console.log("🔊 Playing alarm sound:", currentAlarm.sound);
    
    // Play the alarm sound
    audioService.playSound(currentAlarm.sound, true);

    // Vibrate device
    import('@/lib/vibrationService').then(({ vibrationService }) => {
      vibrationService.startAlarmVibration();
    });

    // Cleanup on unmount - CRITICAL: Stop sound when component unmounts
    // BUT: Don't stop if TicTacToe modal is showing (just hiding the component)
    return () => {
      console.log("🧹 AlarmRinging component unmounting - cleaning up...");
      
      // Only stop sound if we're not showing TicTacToe
      // This prevents sound from stopping when modal appears
      if (!showTicTacToe) {
        audioService.stopSound();
        import('@/lib/vibrationService').then(({ vibrationService }) => {
          vibrationService.stopVibration();
        });
      } else {
        console.log("🎮 TicTacToe modal showing, keeping sound playing...");
      }
    };
  }, [params?.id, currentAlarm, setLocation, showTicTacToe]);

  if (!currentAlarm) {
    return null;
  }

  const formatTime = () => {
    const hour = currentAlarm.hour.toString().padStart(2, "0");
    const minute = currentAlarm.minute.toString().padStart(2, "0");
    return `${hour}:${minute} ${currentAlarm.period}`;
  };

  const handleSnooze = (minutes: number) => {
    if (!currentAlarm) return;

    console.log("😴 Snooze button clicked for:", minutes, "minutes");

    // Try to snooze the alarm
    const snoozed = alarmScheduler.snooze(currentAlarm.id, minutes);

    if (snoozed) {
      const snoozeInfo = alarmScheduler.getSnoozeInfo(currentAlarm.id);
      const count = snoozeInfo?.snoozeCount || 0;
      const maxCount = currentAlarm.maxSnoozeCount === "forever" ? "∞" : currentAlarm.maxSnoozeCount;

      toast({
        title: "Alarm snoozed",
        description: `Will ring again in ${minutes} minutes (${count}/${maxCount} snoozes)`,
      });

      console.log("😴 Stopping sound before returning to alarm list...");
      // Stop the sound and return to alarm list
      audioService.stopSound();
      
      console.log("😴 Navigating to home...");
      setLocation("/");
    } else {
      // Max snooze count reached
      toast({
        title: "Cannot snooze",
        description: "Maximum snooze limit reached. Please dismiss the alarm.",
        variant: "destructive",
      });
    }
  };

  const handleDismiss = () => {
    console.log("🔴 Dismiss button clicked, requireTicTacToe:", currentAlarm.requireTicTacToe);
    
    if (currentAlarm.requireTicTacToe) {
      console.log("✅ Showing TicTacToe game...");
      setShowTicTacToe(true);
    } else {
      console.log("🔴 Dismiss alarm without TicTacToe");
      dismissAlarm();
    }
  };

  const dismissAlarm = () => {
    if (!currentAlarm) {
      console.log("❌ No current alarm to dismiss");
      return;
    }

    console.log("🛑 dismissAlarm() called for alarm:", currentAlarm.id);

    // STEP 1: Stop the sound immediately
    console.log("🛑 Step 1: Stopping sound...");
    audioService.stopSound();

    // STEP 2: Stop vibration
    console.log("🛑 Step 2: Stopping vibration...");
    import('@/lib/vibrationService').then(({ vibrationService }) => {
      vibrationService.stopVibration();
    });

    // STEP 3: Clear any snooze data for this alarm
    console.log("🛑 Step 3: Clearing snooze data...");
    alarmScheduler.clearSnooze(currentAlarm.id);

    // STEP 4: If this is a one-time alarm (no recurring days), disable it
    if (currentAlarm.days.length === 0) {
      console.log("🛑 Step 4: Disabling one-time alarm after dismissal");
      updateAlarm(currentAlarm.id, { isActive: false });
    }

    // STEP 5: Navigate back to home
    console.log("🛑 Step 5: Navigating to home page...");
    setLocation("/");
    
    console.log("✅ Alarm dismissed successfully");
  };

  const handleGameComplete = () => {
    console.log("🎮 TicTacToe game completed!");
    
    // Dismiss the alarm immediately (sound will stop in dismissAlarm)
    console.log("🎮 Calling dismissAlarm()...");
    dismissAlarm();
  };

  return (
    <>
      {!showTicTacToe && (
        <AlarmRinging
          time={formatTime()}
          label={currentAlarm.label}
          snoozeDuration={parseInt(currentAlarm.snooze)}
          onSnooze={handleSnooze}
          onDismiss={handleDismiss}
        />
      )}
      {showTicTacToe && <TicTacToeModal onComplete={handleGameComplete} />}
    </>
  );
}