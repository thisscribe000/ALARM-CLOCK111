import { useState, useEffect } from "react";
import { useLocation } from "wouter";
import Header from "@/components/Header";
import AlarmCard from "@/components/AlarmCard";
import AddAlarmButton from "@/components/AddAlarmButton";
import { Button } from "@/components/ui/button";
import { Settings } from "lucide-react";
import { getAlarms, toggleAlarm, type Alarm } from "@/lib/alarmStore";

export default function Alarms() {
  const [, setLocation] = useLocation();
  const [alarms, setAlarms] = useState<Alarm[]>([]);

  useEffect(() => {
    loadAlarms();
  }, []);

  const loadAlarms = () => {
    const loadedAlarms = getAlarms();
    setAlarms(loadedAlarms);
  };

  const handleToggleAlarm = (id: string) => {
    toggleAlarm(id);
    loadAlarms();
  };

  const handleEditAlarm = (id: string) => {
    setLocation(`/alarm/${id}`);
  };

  const handleAddAlarm = () => {
    setLocation("/alarm/new");
  };

  const formatTime = (alarm: Alarm) => {
    const hour = alarm.hour.toString().padStart(2, "0");
    const minute = alarm.minute.toString().padStart(2, "0");
    return `${hour}:${minute} ${alarm.period}`;
  };

  const getTimeUntilAlarm = (alarm: Alarm): string => {
    if (!alarm.isActive || !alarm.nextTrigger) return "";
    
    const now = Date.now();
    const diff = alarm.nextTrigger - now;
    
    if (diff <= 0) return "Ringing now";
    
    const totalMinutes = Math.floor(diff / (1000 * 60));
    const totalHours = Math.floor(totalMinutes / 60);
    const days = Math.floor(totalHours / 24);
    const hours = totalHours % 24;
    const minutes = totalMinutes % 60;
    
    const parts = [];
    if (days > 0) parts.push(`${days}d`);
    if (hours > 0) parts.push(`${hours}h`);
    if (minutes > 0 || parts.length === 0) parts.push(`${minutes}m`);
    
    return `in ${parts.join(' ')}`;
  };

  return (
    <div className="flex flex-col h-full">
      <Header 
        title="Alarms" 
        action={
          <Button
            variant="ghost"
            size="icon"
            onClick={() => setLocation("/settings")}
          >
            <Settings className="w-5 h-5" />
          </Button>
        }
      />
      <div className="flex-1 overflow-y-auto p-6 space-y-4">
        {alarms.length === 0 ? (
          <div className="flex flex-col items-center justify-center py-12 text-center">
            <p className="text-muted-foreground mb-2">No alarms yet</p>
            <p className="text-sm text-muted-foreground">Tap the button below to create your first alarm</p>
          </div>
        ) : (
          alarms.map((alarm) => (
            <AlarmCard
              key={alarm.id}
              time={formatTime(alarm)}
              label={alarm.label}
              isActive={alarm.isActive}
              days={alarm.days}
              isHighlighted={alarm.isActive}
              subtitle={getTimeUntilAlarm(alarm)}
              onToggle={() => handleToggleAlarm(alarm.id)}
              onClick={() => handleEditAlarm(alarm.id)}
            />
          ))
        )}
        <AddAlarmButton onClick={handleAddAlarm} />
      </div>
    </div>
  );
}
