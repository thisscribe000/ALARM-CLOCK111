import { useState, useEffect } from "react";
import { useLocation, useRoute } from "wouter";
import Header from "@/components/Header";
import TimePicker from "@/components/TimePicker";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Switch } from "@/components/ui/switch";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Check, X, Trash2 } from "lucide-react";
import { getAlarms, saveAlarm, updateAlarm, deleteAlarm } from "@/lib/alarmStore";
import { useToast } from "@/hooks/use-toast";

export default function EditAlarm() {
  const [, setLocation] = useLocation();
  const [, params] = useRoute("/alarm/:id");
  const { toast } = useToast();
  const isNew = params?.id === "new";

  // Get initial time - either from existing alarm or current time
  const getInitialTime = () => {
    if (!isNew && params?.id) {
      const alarms = getAlarms();
      const alarm = alarms.find((a) => a.id === params.id);
      if (alarm) {
        return { hour: alarm.hour, minute: alarm.minute, period: alarm.period };
      }
    }
    
    // For new alarms, use EXACT current system time with NO modifications
    const now = new Date();
    let hour = now.getHours();
    const minute = now.getMinutes(); // Exact current minute - no rounding or additions
    const period: "AM" | "PM" = hour >= 12 ? "PM" : "AM";
    
    // Convert to 12-hour format
    if (hour === 0) hour = 12;
    else if (hour > 12) hour = hour - 12;
    
    return { hour, minute, period };
  };

  const [time, setTime] = useState(getInitialTime());
  const [label, setLabel] = useState("");
  const [selectedDays, setSelectedDays] = useState<string[]>(["Mon", "Tues", "Wed", "Thur", "Fri"]);
  const [sound, setSound] = useState("default");
  const [snooze, setSnooze] = useState("10");
  const [maxSnoozeCount, setMaxSnoozeCount] = useState("3");
  const [requireTicTacToe, setRequireTicTacToe] = useState(false);

  const days = ["Mon", "Tues", "Wed", "Thur", "Fri", "Sat", "Sun"];
  const dayLabels: Record<string, string> = {
    "Mon": "M",
    "Tues": "T",
    "Wed": "W",
    "Thur": "T",
    "Fri": "F",
    "Sat": "S",
    "Sun": "S"
  };

  useEffect(() => {
    if (!isNew && params?.id) {
      const alarms = getAlarms();
      const alarm = alarms.find((a) => a.id === params.id);
      
      if (alarm) {
        // Time is already set in getInitialTime, so we only need to update other fields
        setLabel(alarm.label);
        setSelectedDays(alarm.days);
        setSound(alarm.sound);
        setSnooze(alarm.snooze);
        setMaxSnoozeCount(alarm.maxSnoozeCount || "3");
        setRequireTicTacToe(alarm.requireTicTacToe);
      }
    }
  }, [isNew, params?.id]);

  const toggleDay = (day: string) => {
    setSelectedDays((prev) =>
      prev.includes(day) ? prev.filter((d) => d !== day) : [...prev, day]
    );
  };

  const handleSave = () => {
    const alarmData = {
      label: label || "Alarm",
      hour: time.hour,
      minute: time.minute,
      period: time.period,
      days: selectedDays,
      sound,
      snooze,
      maxSnoozeCount,
      requireTicTacToe,
      isActive: true,
    };

    if (isNew) {
      saveAlarm(alarmData);
      toast({
        title: "Alarm created",
        description: "Your new alarm has been saved.",
      });
    } else if (params?.id) {
      updateAlarm(params.id, alarmData);
      toast({
        title: "Alarm updated",
        description: "Your alarm has been saved.",
      });
    }

    setLocation("/");
  };

  const handleDelete = () => {
    if (!isNew && params?.id) {
      deleteAlarm(params.id);
      toast({
        title: "Alarm deleted",
        description: "Your alarm has been removed.",
        variant: "destructive",
      });
      setLocation("/");
    }
  };

  const handleCancel = () => {
    setLocation("/");
  };

  return (
    <div className="flex flex-col h-full">
      <Header
        title={isNew ? "Add alarm" : "Edit alarm"}
        onBack={handleCancel}
        action={
          !isNew && (
            <Button
              variant="ghost"
              size="icon"
              onClick={handleDelete}
              data-testid="button-delete"
            >
              <Trash2 className="w-5 h-5 text-destructive" />
            </Button>
          )
        }
      />
      <div className="flex-1 overflow-y-auto p-6">
        <div className="space-y-6">
          {/* Name Input */}
          <div className="space-y-2">
            <Label htmlFor="alarm-label" className="text-sm font-medium text-muted-foreground">
              Set name
            </Label>
            <Input
              id="alarm-label"
              value={label}
              onChange={(e) => setLabel(e.target.value)}
              placeholder="Alarm"
              className="h-12 text-base"
              data-testid="input-alarm-label"
            />
          </div>

          {/* Time Picker */}
          <TimePicker value={time} onChange={setTime} />

          {/* Day Selection */}
          <div className="space-y-3">
            <Label className="text-sm font-medium text-muted-foreground">Repeat</Label>
            <div className="flex flex-wrap gap-2">
              {days.map((day) => (
                <button
                  key={day}
                  onClick={() => toggleDay(day)}
                  className={`px-4 py-2 rounded-lg text-sm font-semibold transition-colors ${
                    selectedDays.includes(day)
                      ? "bg-primary text-primary-foreground"
                      : "bg-secondary text-secondary-foreground hover-elevate"
                  }`}
                  data-testid={`button-day-${day}`}
                >
                  {dayLabels[day]}
                </button>
              ))}
            </div>
          </div>

          {/* Sound Selection */}
          <div className="space-y-2">
            <Label htmlFor="sound" className="text-sm font-medium text-muted-foreground">
              Sound
            </Label>
            <Select value={sound} onValueChange={setSound}>
              <SelectTrigger id="sound" className="h-12" data-testid="select-sound">
                <SelectValue placeholder="Select sound" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="default">Default</SelectItem>
                <SelectItem value="gentle">Gentle Wake</SelectItem>
                <SelectItem value="loud">Loud Alarm</SelectItem>
                <SelectItem value="birdsong">Birdsong</SelectItem>
                <SelectItem value="chimes">Chimes</SelectItem>
              </SelectContent>
            </Select>
          </div>

          {/* Snooze Duration */}
          <div className="space-y-2">
            <Label htmlFor="snooze" className="text-sm font-medium text-muted-foreground">
              Snooze duration
            </Label>
            <Select value={snooze} onValueChange={setSnooze}>
              <SelectTrigger id="snooze" className="h-12" data-testid="select-snooze">
                <SelectValue placeholder="Select snooze" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="5">5 minutes</SelectItem>
                <SelectItem value="10">10 minutes</SelectItem>
                <SelectItem value="15">15 minutes</SelectItem>
                <SelectItem value="30">30 minutes</SelectItem>
              </SelectContent>
            </Select>
          </div>

          {/* Max Snooze Count */}
          <div className="space-y-2">
            <Label htmlFor="maxSnooze" className="text-sm font-medium text-muted-foreground">
              Max snooze count
            </Label>
            <Select value={maxSnoozeCount} onValueChange={setMaxSnoozeCount}>
              <SelectTrigger id="maxSnooze" className="h-12" data-testid="select-max-snooze">
                <SelectValue placeholder="Select max snoozes" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="3">3 times</SelectItem>
                <SelectItem value="5">5 times</SelectItem>
                <SelectItem value="forever">Forever</SelectItem>
              </SelectContent>
            </Select>
          </div>

          {/* TicTacToe Toggle */}
          <div className="flex items-center justify-between py-3">
            <div className="space-y-0.5">
              <Label htmlFor="tictactoe" className="text-base font-medium">
                Require TicTacToe to dismiss
              </Label>
              <p className="text-sm text-muted-foreground">
                Win a game to turn off alarm
              </p>
            </div>
            <Switch
              id="tictactoe"
              checked={requireTicTacToe}
              onCheckedChange={setRequireTicTacToe}
              data-testid="switch-tictactoe"
            />
          </div>

          {/* Action Buttons */}
          <div className="flex gap-4 pt-4">
            <Button
              variant="outline"
              size="lg"
              className="flex-1 h-14"
              onClick={handleCancel}
              data-testid="button-cancel"
            >
              <X className="w-5 h-5 mr-2" />
              Cancel
            </Button>
            <Button
              variant="default"
              size="lg"
              className="flex-1 h-14"
              onClick={handleSave}
              data-testid="button-save"
            >
              <Check className="w-5 h-5 mr-2" />
              Save
            </Button>
          </div>
        </div>
      </div>
    </div>
  );
}
