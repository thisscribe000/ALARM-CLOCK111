export default function Home() {
  return (
    <div className="flex flex-col items-center justify-center h-full p-6">
      <div className="text-center space-y-4">
        <h1 className="text-3xl font-bold text-foreground">
          Welcome
        </h1>
        <p className="text-muted-foreground">
          Your mobile-first app is ready to build
        </p>
      </div>
    </div>
  );
}
