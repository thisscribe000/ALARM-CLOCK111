
import { useState, useEffect } from "react";
import { useLocation } from "wouter";
import Header from "@/components/Header";
import { Label } from "@/components/ui/label";
import { Button } from "@/components/ui/button";
import { Textarea } from "@/components/ui/textarea";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { RadioGroup, RadioGroupItem } from "@/components/ui/radio-group";
import { getSettings, updateSettings, saveFeedback, type Settings } from "@/lib/settingsStore";
import { useToast } from "@/hooks/use-toast";

export default function SettingsPage() {
  const [, setLocation] = useLocation();
  const { toast } = useToast();
  const [settings, setSettings] = useState<Settings>(getSettings());
  const [feedback, setFeedback] = useState("");

  useEffect(() => {
    // Load settings on mount
    const loadedSettings = getSettings();
    setSettings(loadedSettings);
  }, []);

  const handleSettingChange = (key: keyof Settings, value: any) => {
    const updated = updateSettings({ [key]: value });
    setSettings(updated);
    
    toast({
      title: "Settings updated",
      description: "Your preferences have been saved.",
    });
  };

  const handleFeedbackSubmit = () => {
    if (!feedback.trim()) {
      toast({
        title: "Empty feedback",
        description: "Please enter some feedback before submitting.",
        variant: "destructive",
      });
      return;
    }

    saveFeedback(feedback);
    setFeedback("");
    
    toast({
      title: "Feedback submitted",
      description: "Thank you for your feedback!",
    });
  };

  const handleFileUpload = (event: React.ChangeEvent<HTMLInputElement>) => {
    const file = event.target.files?.[0];
    if (!file) return;

    if (!file.type.startsWith("audio/")) {
      toast({
        title: "Invalid file",
        description: "Please upload an audio file.",
        variant: "destructive",
      });
      return;
    }

    // Create a URL for the uploaded file
    const url = URL.createObjectURL(file);
    handleSettingChange("customSoundUrl", url);
    handleSettingChange("alarmSoundOption", "custom");
    
    toast({
      title: "Custom sound uploaded",
      description: "Your custom alarm sound has been set.",
    });
  };

  return (
    <div className="flex flex-col h-full">
      <Header title="Settings" onBack={() => setLocation("/")} />
      
      <div className="flex-1 overflow-y-auto p-6 space-y-6">
        {/* Theme Settings */}
        <div className="space-y-3">
          <h2 className="text-lg font-semibold">Appearance</h2>
          <div className="space-y-2">
            <Label htmlFor="theme">Theme</Label>
            <Select
              value={settings.theme}
              onValueChange={(value: any) => handleSettingChange("theme", value)}
            >
              <SelectTrigger id="theme">
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="light">Light</SelectItem>
                <SelectItem value="dark">Dark</SelectItem>
                <SelectItem value="system">System</SelectItem>
              </SelectContent>
            </Select>
          </div>
        </div>

        {/* Time Format */}
        <div className="space-y-3">
          <h2 className="text-lg font-semibold">Time Format</h2>
          <div className="flex items-center justify-between">
            <div className="space-y-0.5">
              <Label htmlFor="24hour">24-hour time</Label>
              <p className="text-sm text-muted-foreground">
                {settings.use24HourTime === "system" ? "Following device settings" : settings.use24HourTime ? "Enabled" : "Disabled"}
              </p>
            </div>
            <Select
              value={settings.use24HourTime.toString()}
              onValueChange={(value) => 
                handleSettingChange("use24HourTime", value === "system" ? "system" : value === "true")
              }
            >
              <SelectTrigger className="w-32">
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="system">System</SelectItem>
                <SelectItem value="true">On</SelectItem>
                <SelectItem value="false">Off</SelectItem>
              </SelectContent>
            </Select>
          </div>
        </div>

        {/* Tic-Tac-Toe Difficulty */}
        <div className="space-y-3">
          <h2 className="text-lg font-semibold">Tic-Tac-Toe Challenge</h2>
          <div className="space-y-2">
            <Label htmlFor="difficulty">AI Difficulty</Label>
            <Select
              value={settings.ticTacToeDifficulty}
              onValueChange={(value: any) => handleSettingChange("ticTacToeDifficulty", value)}
            >
              <SelectTrigger id="difficulty">
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="easy">Easy</SelectItem>
                <SelectItem value="medium">Medium</SelectItem>
                <SelectItem value="hard">Hard</SelectItem>
              </SelectContent>
            </Select>
            <p className="text-sm text-muted-foreground">
              Applies to alarms with Tic-Tac-Toe dismissal enabled
            </p>
          </div>
        </div>

        {/* Alarm Sound Settings */}
        <div className="space-y-3">
          <h2 className="text-lg font-semibold">Alarm Sound</h2>
          <RadioGroup
            value={settings.alarmSoundOption}
            onValueChange={(value: any) => handleSettingChange("alarmSoundOption", value)}
          >
            <div className="flex items-center space-x-2">
              <RadioGroupItem value="default" id="sound-default" />
              <Label htmlFor="sound-default">Device default</Label>
            </div>
            <div className="flex items-center space-x-2">
              <RadioGroupItem value="choose" id="sound-choose" />
              <Label htmlFor="sound-choose">Choose from library</Label>
            </div>
            <div className="flex items-center space-x-2">
              <RadioGroupItem value="custom" id="sound-custom" />
              <Label htmlFor="sound-custom">Upload custom sound</Label>
            </div>
          </RadioGroup>
          
          {settings.alarmSoundOption === "custom" && (
            <div className="mt-3">
              <input
                type="file"
                accept="audio/*"
                onChange={handleFileUpload}
                className="text-sm text-muted-foreground file:mr-4 file:py-2 file:px-4 file:rounded-md file:border-0 file:text-sm file:font-semibold file:bg-primary file:text-primary-foreground hover:file:bg-primary/90"
              />
            </div>
          )}
        </div>

        {/* Feedback */}
        <div className="space-y-3">
          <h2 className="text-lg font-semibold">Feedback</h2>
          <div className="space-y-2">
            <Label htmlFor="feedback">Share your thoughts</Label>
            <Textarea
              id="feedback"
              placeholder="Tell us what you think about the app..."
              value={feedback}
              onChange={(e) => setFeedback(e.target.value)}
              rows={4}
            />
            <Button onClick={handleFeedbackSubmit} className="w-full">
              Submit Feedback
            </Button>
          </div>
        </div>
      </div>
    </div>
  );
}
