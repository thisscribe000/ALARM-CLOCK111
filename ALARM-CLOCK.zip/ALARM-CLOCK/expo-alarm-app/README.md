# Alarm Clock App - Expo/React Native

A feature-rich alarm clock application built with Expo and React Native, featuring customizable alarms, snooze options, and a unique tic-tac-toe dismissal game.

## Features

### Alarm Management
- **Flexible Scheduling**: Create one-time or recurring alarms
- **Custom Days**: Select specific days of the week for recurring alarms
- **Multiple Alarms**: Manage unlimited alarms with individual settings

### Customization Options
- **Alarm Sounds**: Choose from 5 built-in sounds or upload custom audio files
  - Default alarm
  - Gentle wake
  - Loud alarm
  - Birdsong
  - Chimes
- **Snooze Settings**: Configure snooze duration (5, 10, 15, or 30 minutes)
- **Snooze Limits**: Set maximum snooze count (3, 5, or unlimited)
- **Label Support**: Add custom labels to identify alarms

### Unique Features
- **Tic-Tac-Toe Dismissal**: Optional game requirement to dismiss alarms
  - 3 difficulty levels: Easy, Medium, Hard
  - Win the game to turn off the alarm
- **Smart Scheduling**: Automatic calculation of next alarm trigger time
- **Background Notifications**: Alarms work even when app is closed

### User Interface
- **Modern Design**: Clean, mobile-first interface matching iOS/Android design guidelines
- **Dark Mode**: Full support for light, dark, and system theme preferences
- **Intuitive Navigation**: Tab-based navigation with dedicated alarm and settings screens
- **Time Format Options**: Support for 12-hour and 24-hour time formats

## Project Structure

```
expo-alarm-app/
├── app/                      # Expo Router app directory
│   ├── _layout.tsx           # Root layout with providers
│   ├── (tabs)/               # Tab navigation group
│   │   ├── _layout.tsx       # Tabs layout
│   │   ├── index.tsx         # Home/Alarms screen
│   │   └── settings.tsx      # Settings screen
│   ├── alarm/
│   │   └── [id].tsx          # Alarm create/edit screen
│   ├── ringing/
│   │   └── [id].tsx          # Alarm ringing screen
│   └── tictactoe.tsx         # Tic-Tac-Toe game modal
├── src/
│   ├── components/           # Reusable UI components
│   │   ├── Badge.tsx
│   │   ├── Button.tsx
│   │   ├── Card.tsx
│   │   ├── DaySelector.tsx
│   │   ├── Switch.tsx
│   │   └── TimePicker.tsx
│   ├── contexts/             # React contexts
│   │   └── ThemeContext.tsx  # Theme provider
│   ├── lib/                  # Core services
│   │   ├── storage.ts        # AsyncStorage wrapper
│   │   ├── alarmService.ts   # Alarm CRUD operations
│   │   ├── settingsService.ts # Settings management
│   │   ├── notificationService.ts # Expo notifications
│   │   └── audioService.ts   # Audio playback
│   ├── styles/               # Theme and styling
│   │   └── theme.ts          # Design tokens
│   └── types/                # TypeScript types
│       └── index.ts          # Shared type definitions
├── assets/
│   └── sounds/               # Alarm sound files
│       ├── default-alarm.mp3
│       ├── gentle-wake.mp3
│       ├── loud-alarm.mp3
│       ├── birdsong.mp3
│       └── chimes.mp3
├── app.json                  # Expo configuration
├── package.json              # Dependencies
├── tsconfig.json             # TypeScript configuration
└── babel.config.js           # Babel configuration
```

## Installation & Setup

### Prerequisites
- Node.js 18+ and npm/yarn
- Expo CLI: `npm install -g expo-cli`
- iOS Simulator (for Mac) or Android Studio (for Android development)
- Expo Go app on your mobile device (for testing on physical device)

### Steps

1. **Clone or extract the project**
   ```bash
   cd expo-alarm-app
   ```

2. **Install dependencies**
   ```bash
   npm install
   ```

3. **Add actual alarm sound files**
   - Replace placeholder files in `assets/sounds/` with actual MP3 audio files
   - Ensure files are named correctly:
     - `default-alarm.mp3`
     - `gentle-wake.mp3`
     - `loud-alarm.mp3`
     - `birdsong.mp3`
     - `chimes.mp3`

4. **Start the development server**
   ```bash
   npm start
   ```

5. **Run on device/simulator**
   - Press `i` for iOS Simulator
   - Press `a` for Android Emulator
   - Scan QR code with Expo Go app for physical device

## Configuration

### Permissions

The app requires the following permissions:

**iOS:**
- Notifications
- Audio playback in background
- File access (for custom sounds)

**Android:**
- `SCHEDULE_EXACT_ALARM` - Schedule precise alarms
- `USE_EXACT_ALARM` - Use exact alarm API
- `VIBRATE` - Vibration on alarm
- `RECEIVE_BOOT_COMPLETED` - Restore alarms after reboot
- `WAKE_LOCK` - Keep device awake during alarm
- `POST_NOTIFICATIONS` - Show notifications

These permissions are configured in `app.json` and requested at runtime when needed.

### Notification Channels (Android)

The app creates an "Alarms" notification channel with:
- Maximum importance
- Sound enabled
- Vibration enabled
- Bypass Do Not Disturb mode

## Usage Guide

### Creating an Alarm

1. Tap the **+** button on the home screen
2. Set the desired time using the time picker
3. Add a label (optional)
4. Select days for recurring alarm (leave empty for one-time)
5. Choose alarm sound
6. Configure snooze duration and max count
7. Enable tic-tac-toe requirement (optional)
8. Tap **Save**

### Managing Alarms

- **Toggle alarm**: Use the switch on each alarm card
- **Edit alarm**: Tap the "Edit" button
- **Delete alarm**: Tap the "Delete" button
- **View next trigger**: Displayed below alarm label

### Dismissing an Alarm

When an alarm rings:

1. **Without Tic-Tac-Toe**: Tap "Dismiss" to turn off
2. **With Tic-Tac-Toe**: 
   - Tap "Play Tic-Tac-Toe"
   - Win or draw the game to dismiss
   - You play as X, AI plays as O

### Snoozing

- Tap the "Snooze" button when alarm rings
- Alarm will re-trigger after configured duration
- Snooze count is tracked and limited by max setting

### Settings

Access the Settings tab to configure:

- **Theme**: Light, Dark, or System
- **Tic-Tac-Toe Difficulty**: Easy, Medium, or Hard
- **Alarm Sound Option**: Default, Choose per alarm, or Custom
- **24-Hour Time**: Toggle 24-hour time format

## Technical Details

### Data Persistence

- **AsyncStorage**: All data stored locally on device
- **Alarms**: Stored as JSON array with computed trigger times
- **Settings**: Stored as JSON object with defaults
- **No Backend**: Fully offline app, no server required

### Notification Scheduling

- **expo-notifications**: Local notifications scheduled at exact times
- **Recurring Alarms**: Uses `repeats: true` with weekday constraints
- **One-Time Alarms**: Single notification at specified date/time
- **Background Support**: Works when app is closed or device is locked

### Audio Playback

- **expo-av**: Audio.Sound API for alarm playback
- **Looping**: Alarms play in continuous loop
- **Background Mode**: Enabled for iOS
- **Custom Sounds**: Support for user-uploaded audio files

### Game Logic

- **Minimax Algorithm**: AI opponent for tic-tac-toe
- **Difficulty Levels**:
  - Easy: Random moves
  - Medium: 50% random, 50% optimal
  - Hard: Always optimal moves
- **Win Detection**: Checks all win patterns after each move

## Troubleshooting

### Alarms Not Firing

1. **Check Permissions**: Ensure notification permissions are granted
2. **Android Settings**: Enable "Exact Alarms" in app settings
3. **Battery Optimization**: Disable battery optimization for the app
4. **Background Restrictions**: Ensure app can run in background

### Sound Not Playing

1. **Volume**: Check device volume and "Play in Silent Mode" setting
2. **Audio Files**: Ensure sound files exist in `assets/sounds/`
3. **iOS**: Check that background audio is enabled in app capabilities
4. **Permissions**: Grant microphone/audio permissions if prompted

### Development Issues

1. **Metro Bundler**: Restart with `npm start --reset-cache`
2. **Dependencies**: Reinstall with `rm -rf node_modules && npm install`
3. **iOS Build**: Run `npx pod-install` if using bare workflow
4. **Android Build**: Clear build with `cd android && ./gradlew clean`

## Building for Production

### Development Build

```bash
# iOS
npm run ios

# Android
npm run android
```

### Production Build (requires EAS)

```bash
# Install EAS CLI
npm install -g eas-cli

# Login to Expo account
eas login

# Configure build
eas build:configure

# Build for iOS
eas build --platform ios

# Build for Android
eas build --platform android
```

### App Store Submission

Follow Expo's guide for [App Store deployment](https://docs.expo.dev/distribution/app-stores/)

## Known Limitations

1. **iOS Background Limitations**: iOS may restrict background alarm firing in some cases
2. **Notification Limits**: Maximum 64 scheduled notifications at once
3. **Custom Sound Size**: Large audio files may impact app size
4. **Weekday Scheduling**: Complex recurring patterns require multiple notifications

## Future Enhancements

- Cloud sync across devices
- Backup/restore functionality
- More alarm sounds
- Gradual volume increase
- Math problems for dismissal
- Alarm analytics and statistics
- Widget support
- Apple Watch/WearOS integration

## License

This project is provided as-is for educational and personal use.

## Credits

Built with:
- [Expo](https://expo.dev/)
- [React Native](https://reactnative.dev/)
- [Expo Router](https://expo.github.io/router/)
- [expo-notifications](https://docs.expo.dev/versions/latest/sdk/notifications/)
- [expo-av](https://docs.expo.dev/versions/latest/sdk/av/)
- [@react-native-async-storage/async-storage](https://react-native-async-storage.github.io/async-storage/)

## Support

For issues or questions:
1. Check the troubleshooting section
2. Review Expo documentation
3. Check React Native community forums
