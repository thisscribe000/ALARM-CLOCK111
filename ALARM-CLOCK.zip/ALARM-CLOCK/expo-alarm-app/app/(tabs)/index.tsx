import { useState, useEffect, useCallback } from 'react';
import { View, Text, StyleSheet, FlatList, TouchableOpacity, Alert } from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import { useRouter } from 'expo-router';
import { Ionicons } from '@expo/vector-icons';
import { useTheme } from '@/contexts/ThemeContext';
import { getAlarms, toggleAlarm, deleteAlarm, updateAlarm } from '@/lib/alarmService';
import { scheduleAlarmNotification, cancelAlarmNotification } from '@/lib/notificationService';
import { clearSnoozeForAlarm } from '@/lib/snoozeService';
import { getSettings } from '@/lib/settingsService';
import { Alarm } from '@/types';
import Card from '@/components/Card';
import Switch from '@/components/Switch';
import Badge from '@/components/Badge';
import Button from '@/components/Button';
import { spacing, fontSize, fontWeight } from '@/styles/theme';
import { format } from 'date-fns';

export default function HomeScreen() {
  const { colors } = useTheme();
  const router = useRouter();
  const [alarms, setAlarms] = useState<Alarm[]>([]);
  const [refreshing, setRefreshing] = useState(false);
  const [use24Hour, setUse24Hour] = useState(false);

  const loadSettings = useCallback(async () => {
    const settings = await getSettings();
    setUse24Hour(settings.use24HourTime === true);
  }, []);

  const loadAlarms = useCallback(async () => {
    const loadedAlarms = await getAlarms();
    setAlarms(loadedAlarms);
  }, []);

  useEffect(() => {
    loadSettings();
    loadAlarms();
  }, [loadSettings, loadAlarms]);

  const handleRefresh = async () => {
    setRefreshing(true);
    await loadAlarms();
    setRefreshing(false);
  };

  const handleToggle = async (id: string) => {
    const alarm = alarms.find((a) => a.id === id);
    if (!alarm) return;

    const updated = await toggleAlarm(id);
    if (updated) {
      if (updated.isActive) {
        const notificationIds = await scheduleAlarmNotification(updated);
        await updateAlarm(id, { notificationId: notificationIds });
      } else {
        if (alarm.notificationId) {
          const ids = alarm.notificationId.split(',');
          for (const nid of ids) {
            await cancelAlarmNotification(nid);
          }
        }
        await clearSnoozeForAlarm(id);
      }
      await loadAlarms();
    }
  };

  const handleDelete = async (id: string) => {
    const alarm = alarms.find((a) => a.id === id);

    Alert.alert(
      'Delete Alarm',
      'Are you sure you want to delete this alarm?',
      [
        { text: 'Cancel', style: 'cancel' },
        {
          text: 'Delete',
          style: 'destructive',
          onPress: async () => {
            if (alarm?.notificationId) {
              const ids = alarm.notificationId.split(',');
              for (const nid of ids) {
                await cancelAlarmNotification(nid);
              }
            }
            await clearSnoozeForAlarm(id);
            await deleteAlarm(id);
            await loadAlarms();
          },
        },
      ]
    );
  };

  const formatTime = (alarm: Alarm) => {
    let displayHour = alarm.hour;
    if (use24Hour) {
      displayHour = alarm.period === 'PM' && alarm.hour !== 12
        ? alarm.hour + 12
        : (alarm.period === 'AM' && alarm.hour === 12 ? 0 : alarm.hour);
    }
    const h = displayHour.toString().padStart(2, '0');
    const m = alarm.minute.toString().padStart(2, '0');
    return use24Hour ? `${h}:${m}` : `${h}:${m} ${alarm.period}`;
  };


  const formatNextTrigger = (timestamp?: number) => {
    if (!timestamp) return '';
    const date = new Date(timestamp);
    const now = new Date();
    const tomorrow = new Date(now);
    tomorrow.setDate(tomorrow.getDate() + 1);

    if (date.toDateString() === now.toDateString()) {
      return 'Today';
    } else if (date.toDateString() === tomorrow.toDateString()) {
      return 'Tomorrow';
    } else {
      return format(date, 'EEE, MMM d');
    }
  };

  const renderAlarm = ({ item }: { item: Alarm }) => (
    <Card style={styles.alarmCard} testID={`card-alarm-${item.id}`}>
      <View style={styles.alarmHeader}>
        <View style={styles.alarmInfo}>
          <Text style={[styles.time, { color: colors.text }]}>
            {formatTime(item)}
          </Text>
          <Text style={[styles.label, { color: colors.textSecondary }]}>
            {item.label || 'Alarm'}
          </Text>
          {item.nextTrigger && (
            <Text style={[styles.nextTrigger, { color: colors.textTertiary }]}>
              {formatNextTrigger(item.nextTrigger)}
            </Text>
          )}
        </View>
        <Switch
          value={item.isActive}
          onValueChange={() => handleToggle(item.id)}
          testID={`switch-alarm-${item.id}`}
        />
      </View>

      {item.days.length > 0 && (
        <View style={styles.daysContainer}>
          {item.days.map((day) => (
            <Badge key={day} label={day} selected style={styles.dayBadge} />
          ))}
        </View>
      )}

      <View style={styles.actions}>
        <TouchableOpacity
          onPress={() => router.push(`/alarm/${item.id}`)}
          style={styles.actionButton}
          testID={`button-edit-${item.id}`}
        >
          <Ionicons name="create-outline" size={20} color={colors.primary} />
          <Text style={[styles.actionText, { color: colors.primary }]}>Edit</Text>
        </TouchableOpacity>
        <TouchableOpacity
          onPress={() => handleDelete(item.id)}
          style={styles.actionButton}
          testID={`button-delete-${item.id}`}
        >
          <Ionicons name="trash-outline" size={20} color={colors.destructive} />
          <Text style={[styles.actionText, { color: colors.destructive }]}>Delete</Text>
        </TouchableOpacity>
      </View>
    </Card>
  );

  return (
    <SafeAreaView style={[styles.container, { backgroundColor: colors.background }]} edges={['top']}>
      <View style={styles.header}>
        <Text style={[styles.title, { color: colors.text }]}>Alarms</Text>
        <TouchableOpacity
          onPress={() => router.push('/alarm/new')}
          testID="button-add-alarm"
        >
          <Ionicons name="add-circle" size={32} color={colors.primary} />
        </TouchableOpacity>
      </View>

      {alarms.length === 0 ? (
        <View style={styles.emptyState}>
          <Ionicons name="alarm-outline" size={64} color={colors.textTertiary} />
          <Text style={[styles.emptyText, { color: colors.textSecondary }]}>
            No alarms yet
          </Text>
          <Text style={[styles.emptySubtext, { color: colors.textTertiary }]}>
            Tap the + button to create your first alarm
          </Text>
        </View>
      ) : (
        <FlatList
          data={alarms}
          renderItem={renderAlarm}
          keyExtractor={(item) => item.id}
          contentContainerStyle={styles.list}
          refreshing={refreshing}
          onRefresh={handleRefresh}
        />
      )}
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
  },
  header: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    paddingHorizontal: spacing.md,
    paddingVertical: spacing.md,
  },
  title: {
    fontSize: fontSize.xxxl,
    fontWeight: fontWeight.bold,
  },
  list: {
    padding: spacing.md,
    gap: spacing.md,
  },
  alarmCard: {
    gap: spacing.md,
  },
  alarmHeader: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'flex-start',
  },
  alarmInfo: {
    flex: 1,
    gap: spacing.xs,
  },
  time: {
    fontSize: fontSize.xxxl,
    fontWeight: fontWeight.bold,
  },
  label: {
    fontSize: fontSize.base,
  },
  nextTrigger: {
    fontSize: fontSize.sm,
  },
  daysContainer: {
    flexDirection: 'row',
    flexWrap: 'wrap',
    gap: spacing.xs,
  },
  dayBadge: {
    paddingHorizontal: spacing.sm,
    paddingVertical: spacing.xs,
  },
  actions: {
    flexDirection: 'row',
    gap: spacing.md,
    paddingTop: spacing.sm,
    borderTopWidth: 1,
    borderTopColor: 'rgba(0,0,0,0.05)',
  },
  actionButton: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: spacing.xs,
  },
  actionText: {
    fontSize: fontSize.sm,
    fontWeight: fontWeight.medium,
  },
  emptyState: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    gap: spacing.md,
    paddingHorizontal: spacing.xl,
  },
  emptyText: {
    fontSize: fontSize.xl,
    fontWeight: fontWeight.semibold,
  },
  emptySubtext: {
    fontSize: fontSize.base,
    textAlign: 'center',
  },
});