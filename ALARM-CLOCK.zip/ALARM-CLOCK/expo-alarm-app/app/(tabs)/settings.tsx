import { useState, useEffect } from 'react';
import { View, Text, StyleSheet, ScrollView, TouchableOpacity } from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import { Ionicons } from '@expo/vector-icons';
import { useTheme } from '@/contexts/ThemeContext';
import { getSettings, updateSettings, Settings } from '@/lib/settingsService';
import Card from '@/components/Card';
import Switch from '@/components/Switch';
import { spacing, fontSize, fontWeight, borderRadius } from '@/styles/theme';

export default function SettingsScreen() {
  const { colors, theme, setTheme } = useTheme();
  const [settings, setSettingsState] = useState<Settings | null>(null);

  useEffect(() => {
    loadSettings();
  }, []);

  const loadSettings = async () => {
    const loaded = await getSettings();
    setSettingsState(loaded);
  };

  const handleSettingChange = async (key: keyof Settings, value: any) => {
    const updated = await updateSettings({ [key]: value });
    setSettingsState(updated);
  };

  if (!settings) return null;

  const themeOptions: Array<{ label: string; value: 'light' | 'dark' | 'system' }> = [
    { label: 'Light', value: 'light' },
    { label: 'Dark', value: 'dark' },
    { label: 'System', value: 'system' },
  ];

  const difficultyOptions: Array<{ label: string; value: 'easy' | 'medium' | 'hard' }> = [
    { label: 'Easy', value: 'easy' },
    { label: 'Medium', value: 'medium' },
    { label: 'Hard', value: 'hard' },
  ];

  const soundOptions: Array<{ label: string; value: 'default' | 'choose' | 'custom' }> = [
    { label: 'Default', value: 'default' },
    { label: 'Choose per Alarm', value: 'choose' },
    { label: 'Custom', value: 'custom' },
  ];

  return (
    <SafeAreaView style={[styles.container, { backgroundColor: colors.background }]} edges={['top']}>
      <View style={styles.header}>
        <Text style={[styles.title, { color: colors.text }]}>Settings</Text>
      </View>

      <ScrollView style={styles.scrollView} contentContainerStyle={styles.content}>
        <Card>
          <Text style={[styles.sectionTitle, { color: colors.text }]}>Appearance</Text>
          <View style={styles.optionsGrid}>
            {themeOptions.map((option) => (
              <TouchableOpacity
                key={option.value}
                onPress={() => {
                  setTheme(option.value);
                  handleSettingChange('theme', option.value);
                }}
                style={[
                  styles.optionButton,
                  {
                    backgroundColor: theme === option.value ? colors.primary : colors.muted,
                    borderColor: theme === option.value ? colors.primary : colors.border,
                  },
                ]}
                testID={`button-theme-${option.value}`}
              >
                <Text
                  style={[
                    styles.optionText,
                    {
                      color: theme === option.value ? colors.primaryForeground : colors.text,
                    },
                  ]}
                >
                  {option.label}
                </Text>
              </TouchableOpacity>
            ))}
          </View>
        </Card>

        <Card>
          <Text style={[styles.sectionTitle, { color: colors.text }]}>Tic-Tac-Toe Difficulty</Text>
          <View style={styles.optionsGrid}>
            {difficultyOptions.map((option) => (
              <TouchableOpacity
                key={option.value}
                onPress={() => handleSettingChange('ticTacToeDifficulty', option.value)}
                style={[
                  styles.optionButton,
                  {
                    backgroundColor:
                      settings.ticTacToeDifficulty === option.value ? colors.primary : colors.muted,
                    borderColor:
                      settings.ticTacToeDifficulty === option.value ? colors.primary : colors.border,
                  },
                ]}
                testID={`button-difficulty-${option.value}`}
              >
                <Text
                  style={[
                    styles.optionText,
                    {
                      color:
                        settings.ticTacToeDifficulty === option.value
                          ? colors.primaryForeground
                          : colors.text,
                    },
                  ]}
                >
                  {option.label}
                </Text>
              </TouchableOpacity>
            ))}
          </View>
        </Card>

        <Card>
          <Text style={[styles.sectionTitle, { color: colors.text }]}>Alarm Sound</Text>
          <View style={styles.optionsGrid}>
            {soundOptions.map((option) => (
              <TouchableOpacity
                key={option.value}
                onPress={() => handleSettingChange('alarmSoundOption', option.value)}
                style={[
                  styles.optionButton,
                  {
                    backgroundColor:
                      settings.alarmSoundOption === option.value ? colors.primary : colors.muted,
                    borderColor:
                      settings.alarmSoundOption === option.value ? colors.primary : colors.border,
                  },
                ]}
                testID={`button-sound-option-${option.value}`}
              >
                <Text
                  style={[
                    styles.optionText,
                    {
                      color:
                        settings.alarmSoundOption === option.value
                          ? colors.primaryForeground
                          : colors.text,
                    },
                  ]}
                >
                  {option.label}
                </Text>
              </TouchableOpacity>
            ))}
          </View>
        </Card>

        <Card>
          <View style={styles.switchRow}>
            <View style={styles.switchLabel}>
              <Text style={[styles.sectionTitle, { color: colors.text }]}>24-Hour Time</Text>
              <Text style={[styles.hint, { color: colors.textTertiary }]}>
                Display time in 24-hour format
              </Text>
            </View>
            <Switch
              value={settings.use24HourTime === true}
              onValueChange={(value) =>
                handleSettingChange('use24HourTime', value ? true : 'system')
              }
              testID="switch-24hour"
            />
          </View>
        </Card>

        <Card>
          <View style={styles.infoRow}>
            <Ionicons name="information-circle" size={24} color={colors.primary} />
            <View style={styles.infoText}>
              <Text style={[styles.label, { color: colors.text }]}>About</Text>
              <Text style={[styles.hint, { color: colors.textSecondary }]}>
                Alarm Clock v1.0.0
              </Text>
              <Text style={[styles.hint, { color: colors.textTertiary }]}>
                Built with Expo and React Native
              </Text>
            </View>
          </View>
        </Card>
      </ScrollView>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
  },
  header: {
    paddingHorizontal: spacing.md,
    paddingVertical: spacing.md,
  },
  title: {
    fontSize: fontSize.xxxl,
    fontWeight: fontWeight.bold,
  },
  scrollView: {
    flex: 1,
  },
  content: {
    padding: spacing.md,
    gap: spacing.md,
  },
  sectionTitle: {
    fontSize: fontSize.base,
    fontWeight: fontWeight.semibold,
    marginBottom: spacing.sm,
  },
  optionsGrid: {
    flexDirection: 'row',
    flexWrap: 'wrap',
    gap: spacing.sm,
  },
  optionButton: {
    paddingHorizontal: spacing.md,
    paddingVertical: spacing.sm,
    borderRadius: borderRadius.md,
    borderWidth: 1,
  },
  optionText: {
    fontSize: fontSize.sm,
    fontWeight: fontWeight.medium,
  },
  switchRow: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    gap: spacing.md,
  },
  switchLabel: {
    flex: 1,
  },
  hint: {
    fontSize: fontSize.sm,
    marginTop: spacing.xs,
  },
  infoRow: {
    flexDirection: 'row',
    gap: spacing.md,
    alignItems: 'flex-start',
  },
  infoText: {
    flex: 1,
    gap: spacing.xs,
  },
  label: {
    fontSize: fontSize.base,
    fontWeight: fontWeight.medium,
  },
});
