import { useEffect } from 'react';
import { Stack } from 'expo-router';
import { StatusBar } from 'expo-status-bar';
import * as SplashScreen from 'expo-splash-screen';
import * as Notifications from 'expo-notifications';
import { ThemeProvider } from '@/contexts/ThemeContext';
import { registerNotificationHandler } from '@/lib/notificationService';

SplashScreen.preventAutoHideAsync();

Notifications.setNotificationHandler({
  handleNotification: async () => ({
    shouldShowAlert: true,
    shouldPlaySound: true,
    shouldSetBadge: false,
  }),
});

export default function RootLayout() {
  useEffect(() => {
    async function prepare() {
      try {
        await registerNotificationHandler();
        await SplashScreen.hideAsync();
      } catch (e) {
        console.warn(e);
      }
    }

    prepare();
  }, []);

  return (
    <ThemeProvider>
      <StatusBar style="auto" />
      <Stack
        screenOptions={{
          headerShown: false,
          contentStyle: { backgroundColor: '#F5F5F5' },
        }}
      >
        <Stack.Screen name="(tabs)" options={{ headerShown: false }} />
        <Stack.Screen 
          name="alarm/[id]" 
          options={{ 
            presentation: 'card',
            headerShown: false 
          }} 
        />
        <Stack.Screen 
          name="ringing/[id]" 
          options={{ 
            presentation: 'fullScreenModal',
            headerShown: false,
            gestureEnabled: false
          }} 
        />
        <Stack.Screen 
          name="tictactoe" 
          options={{ 
            presentation: 'modal',
            headerShown: false
          }} 
        />
      </Stack>
    </ThemeProvider>
  );
}
