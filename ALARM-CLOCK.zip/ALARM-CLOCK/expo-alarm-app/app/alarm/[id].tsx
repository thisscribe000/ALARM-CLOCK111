import { useState, useEffect } from 'react';
import { View, Text, StyleSheet, ScrollView, TextInput, TouchableOpacity, Alert } from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import { useRouter, useLocalSearchParams } from 'expo-router';
import { Ionicons } from '@expo/vector-icons';
import * as DocumentPicker from 'expo-document-picker';
import { useTheme } from '@/contexts/ThemeContext';
import { getAlarmById, saveAlarm, updateAlarm } from '@/lib/alarmService';
import { cancelAlarmNotification, scheduleAlarmNotification } from '@/lib/notificationService';
import { clearSnoozeForAlarm } from '@/lib/snoozeService';
import { getSettings } from '@/lib/settingsService';
import { Alarm } from '@/types';
import Card from '@/components/Card';
import Button from '@/components/Button';
import Switch from '@/components/Switch';
import DaySelector from '@/components/DaySelector';
import TimePicker from '@/components/TimePicker';
import { spacing, fontSize, fontWeight, borderRadius } from '@/styles/theme';

export default function AlarmEditScreen() {
  const { colors } = useTheme();
  const router = useRouter();
  const params = useLocalSearchParams();
  const isNew = params.id === 'new';

  const [label, setLabel] = useState('');
  const [hour, setHour] = useState(7);
  const [minute, setMinute] = useState(0);
  const [period, setPeriod] = useState<'AM' | 'PM'>('AM');
  const [selectedDays, setSelectedDays] = useState<string[]>([]);
  const [sound, setSound] = useState('default');
  const [snooze, setSnooze] = useState('10');
  const [maxSnoozeCount, setMaxSnoozeCount] = useState('3');
  const [requireTicTacToe, setRequireTicTacToe] = useState(false);
  const [use24Hour, setUse24Hour] = useState(false);

  useEffect(() => {
    loadSettings();
    if (!isNew && params.id) {
      loadAlarm();
    } else {
      const now = new Date();
      let h = now.getHours();
      const m = now.getMinutes();
      const p: 'AM' | 'PM' = h >= 12 ? 'PM' : 'AM';
      if (h === 0) h = 12;
      else if (h > 12) h = h - 12;
      setHour(h);
      setMinute(m);
      setPeriod(p);
    }
  }, [params.id, isNew]);

  const loadSettings = async () => {
    const settings = await getSettings();
    setUse24Hour(settings.use24HourTime === true);
  };

  const loadAlarm = async () => {
    const alarm = await getAlarmById(params.id as string);
    if (alarm) {
      setLabel(alarm.label);
      setHour(alarm.hour);
      setMinute(alarm.minute);
      setPeriod(alarm.period);
      setSelectedDays(alarm.days);
      setSound(alarm.sound);
      setSnooze(alarm.snooze);
      setMaxSnoozeCount(alarm.maxSnoozeCount);
      setRequireTicTacToe(alarm.requireTicTacToe);
    }
  };

  const handleSave = async () => {
    const alarmData = {
      label: label || 'Alarm',
      hour,
      minute,
      period,
      days: selectedDays,
      sound,
      snooze,
      maxSnoozeCount,
      requireTicTacToe,
      isActive: true,
    };

    if (isNew) {
      const newAlarm = await saveAlarm(alarmData);
      const notificationIds = await scheduleAlarmNotification(newAlarm);
      await updateAlarm(newAlarm.id, { notificationId: notificationIds });
    } else {
      const existingAlarm = await getAlarmById(params.id as string);
      if (existingAlarm?.notificationId) {
        const ids = existingAlarm.notificationId.split(',');
        for (const nid of ids) {
          await cancelAlarmNotification(nid);
        }
      }

      await clearSnoozeForAlarm(params.id as string);

      const updatedAlarm = await updateAlarm(params.id as string, {
        ...alarmData,
        notificationId: undefined,
      });

      if (updatedAlarm) {
        const notificationIds = await scheduleAlarmNotification(updatedAlarm);
        await updateAlarm(params.id as string, { notificationId: notificationIds });
      }
    }

    // Auto-dismiss alert after showing briefly
    Alert.alert(
      'Success',
      isNew ? 'Alarm created successfully' : 'Alarm updated successfully',
      [
        {
          text: 'OK',
          onPress: () => router.back(),
        },
      ]
    );

    // Auto-navigate back after 1.5 seconds
    setTimeout(() => {
      router.back();
    }, 1500);
  };

  const handleTimeChange = (h: number, m: number, p: 'AM' | 'PM') => {
    setHour(h);
    setMinute(m);
    setPeriod(p);
  };

  const toggleDay = (day: string) => {
    setSelectedDays((prev) =>
      prev.includes(day) ? prev.filter((d) => d !== day) : [...prev, day]
    );
  };

  const soundOptions = [
    { label: 'Default', value: 'default' },
    { label: 'Gentle Wake', value: 'gentle' },
    { label: 'Loud Alarm', value: 'loud' },
    { label: 'Birdsong', value: 'birdsong' },
    { label: 'Chimes', value: 'chimes' },
  ];

  const snoozeOptions = [
    { label: '5 minutes', value: '5' },
    { label: '10 minutes', value: '10' },
    { label: '15 minutes', value: '15' },
    { label: '30 minutes', value: '30' },
  ];

  const maxSnoozeOptions = [
    { label: '3 times', value: '3' },
    { label: '5 times', value: '5' },
    { label: 'Unlimited', value: 'forever' },
  ];

  return (
    <SafeAreaView style={[styles.container, { backgroundColor: colors.background }]} edges={['top']}>
      <View style={styles.header}>
        <TouchableOpacity onPress={() => router.back()} testID="button-back">
          <Ionicons name="arrow-back" size={24} color={colors.text} />
        </TouchableOpacity>
        <Text style={[styles.title, { color: colors.text }]}>
          {isNew ? 'New Alarm' : 'Edit Alarm'}
        </Text>
        <TouchableOpacity onPress={handleSave} testID="button-save">
          <Text style={[styles.saveText, { color: colors.primary }]}>Save</Text>
        </TouchableOpacity>
      </View>

      <ScrollView style={styles.scrollView} contentContainerStyle={styles.content}>
        <Card>
          <TimePicker
            hour={hour}
            minute={minute}
            period={period}
            onChange={handleTimeChange}
            use24Hour={use24Hour}
            testID="time-picker"
          />
        </Card>

        <Card>
          <Text style={[styles.label, { color: colors.textSecondary }]}>Label</Text>
          <TextInput
            value={label}
            onChangeText={setLabel}
            placeholder="Alarm"
            placeholderTextColor={colors.textTertiary}
            style={[
              styles.input,
              {
                color: colors.text,
                backgroundColor: colors.muted,
                borderColor: colors.border,
              },
            ]}
            testID="input-label"
          />
        </Card>

        <Card>
          <Text style={[styles.label, { color: colors.textSecondary }]}>Repeat</Text>
          <DaySelector
            selectedDays={selectedDays}
            onToggleDay={toggleDay}
            testID="day-selector"
          />
          <Text style={[styles.hint, { color: colors.textTertiary }]}>
            {selectedDays.length === 0 ? 'One-time alarm' : 'Repeats on selected days'}
          </Text>
        </Card>

        <Card>
          <Text style={[styles.label, { color: colors.textSecondary }]}>Sound</Text>
          <View style={styles.optionsGrid}>
            {soundOptions.map((option) => (
              <TouchableOpacity
                key={option.value}
                onPress={() => setSound(option.value)}
                style={[
                  styles.optionButton,
                  {
                    backgroundColor: sound === option.value ? colors.primary : colors.muted,
                    borderColor: sound === option.value ? colors.primary : colors.border,
                  },
                ]}
                testID={`button-sound-${option.value}`}
              >
                <Text
                  style={[
                    styles.optionText,
                    {
                      color: sound === option.value ? colors.primaryForeground : colors.text,
                    },
                  ]}
                >
                  {option.label}
                </Text>
              </TouchableOpacity>
            ))}
          </View>
        </Card>

        <Card>
          <Text style={[styles.label, { color: colors.textSecondary }]}>Snooze Duration</Text>
          <View style={styles.optionsGrid}>
            {snoozeOptions.map((option) => (
              <TouchableOpacity
                key={option.value}
                onPress={() => setSnooze(option.value)}
                style={[
                  styles.optionButton,
                  {
                    backgroundColor: snooze === option.value ? colors.primary : colors.muted,
                    borderColor: snooze === option.value ? colors.primary : colors.border,
                  },
                ]}
                testID={`button-snooze-${option.value}`}
              >
                <Text
                  style={[
                    styles.optionText,
                    {
                      color: snooze === option.value ? colors.primaryForeground : colors.text,
                    },
                  ]}
                >
                  {option.label}
                </Text>
              </TouchableOpacity>
            ))}
          </View>
        </Card>

        <Card>
          <Text style={[styles.label, { color: colors.textSecondary }]}>Max Snooze Count</Text>
          <View style={styles.optionsGrid}>
            {maxSnoozeOptions.map((option) => (
              <TouchableOpacity
                key={option.value}
                onPress={() => setMaxSnoozeCount(option.value)}
                style={[
                  styles.optionButton,
                  {
                    backgroundColor: maxSnoozeCount === option.value ? colors.primary : colors.muted,
                    borderColor: maxSnoozeCount === option.value ? colors.primary : colors.border,
                  },
                ]}
                testID={`button-max-snooze-${option.value}`}
              >
                <Text
                  style={[
                    styles.optionText,
                    {
                      color: maxSnoozeCount === option.value ? colors.primaryForeground : colors.text,
                    },
                  ]}
                >
                  {option.label}
                </Text>
              </TouchableOpacity>
            ))}
          </View>
        </Card>

        <Card style={requireTicTacToe ? { backgroundColor: colors.primary + '15', borderColor: colors.primary } : undefined}>
          <View style={styles.switchRow}>
            <View>
              <Text style={[styles.label, { color: requireTicTacToe ? colors.primary : colors.text }]}>
                Require Tic-Tac-Toe to Dismiss
              </Text>
              <Text style={[styles.hint, { color: colors.textTertiary }]}>
                Win the game to turn off alarm
              </Text>
            </View>
            <Switch
              value={requireTicTacToe}
              onValueChange={setRequireTicTacToe}
              testID="switch-tictactoe"
            />
          </View>
        </Card>
      </ScrollView>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
  },
  header: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    paddingHorizontal: spacing.md,
    paddingVertical: spacing.md,
  },
  title: {
    fontSize: fontSize.xl,
    fontWeight: fontWeight.bold,
  },
  saveText: {
    fontSize: fontSize.base,
    fontWeight: fontWeight.semibold,
  },
  scrollView: {
    flex: 1,
  },
  content: {
    padding: spacing.md,
    gap: spacing.md,
  },
  label: {
    fontSize: fontSize.sm,
    fontWeight: fontWeight.medium,
    marginBottom: spacing.sm,
  },
  input: {
    height: 44,
    paddingHorizontal: spacing.md,
    borderRadius: borderRadius.md,
    borderWidth: 1,
    fontSize: fontSize.base,
  },
  hint: {
    fontSize: fontSize.sm,
    marginTop: spacing.xs,
  },
  optionsGrid: {
    flexDirection: 'row',
    flexWrap: 'wrap',
    gap: spacing.sm,
  },
  optionButton: {
    paddingHorizontal: spacing.md,
    paddingVertical: spacing.sm,
    borderRadius: borderRadius.md,
    borderWidth: 1,
  },
  optionText: {
    fontSize: fontSize.sm,
    fontWeight: fontWeight.medium,
  },
  switchRow: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    gap: spacing.md,
  },
});