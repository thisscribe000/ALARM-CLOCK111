import { useState, useEffect } from 'react';
import { View, Text, StyleSheet, TouchableOpacity, Vibration } from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import { useRouter, useLocalSearchParams } from 'expo-router';
import { Ionicons } from '@expo/vector-icons';
import Animated, { 
  useAnimatedStyle, 
  useSharedValue, 
  withTiming,
  Easing 
} from 'react-native-reanimated';
import { useTheme } from '@/contexts/ThemeContext';
import { getAlarmById, updateAlarm } from '@/lib/alarmService';
import { getSettings } from '@/lib/settingsService';
import { audioService } from '@/lib/audioService';
import { 
  addSnooze, 
  getSnoozeForAlarm, 
  clearSnoozeForAlarm,
  scheduleSnoozeNotification 
} from '@/lib/snoozeService';
import { Alarm } from '@/types';
import Button from '@/components/Button';
import { spacing, fontSize, fontWeight } from '@/styles/theme';

const AUTO_DISMISS_DURATION = 5 * 60 * 1000; // 5 minutes

export default function AlarmRingingScreen() {
  const { colors } = useTheme();
  const router = useRouter();
  const params = useLocalSearchParams();
  const [alarm, setAlarm] = useState<Alarm | null>(null);
  const [snoozeCount, setSnoozeCount] = useState(0);
  const progress = useSharedValue(0);

  useEffect(() => {
    loadAlarm();
    
    // Start countdown animation
    progress.value = withTiming(1, {
      duration: AUTO_DISMISS_DURATION,
      easing: Easing.linear,
    });

    // Auto-dismiss after 5 minutes
    const autoDismissTimer = setTimeout(() => {
      dismissAlarm();
    }, AUTO_DISMISS_DURATION);

    return () => {
      audioService.stopSound();
      Vibration.cancel();
      clearTimeout(autoDismissTimer);
    };
  }, [params.id]);

  const loadAlarm = async () => {
    const loadedAlarm = await getAlarmById(params.id as string);
    if (loadedAlarm) {
      setAlarm(loadedAlarm);

      const existingSnooze = await getSnoozeForAlarm(loadedAlarm.id);
      if (existingSnooze) {
        setSnoozeCount(existingSnooze.snoozeCount);
      }

      const settings = await getSettings();
      await audioService.playSound(
        loadedAlarm.sound,
        settings.alarmSoundOption === 'custom' ? settings.customSoundUrl : undefined
      );
      Vibration.vibrate([0, 500, 500, 500], true);
    }
  };

  const handleSnooze = async () => {
    if (!alarm) return;

    const maxSnoozes = alarm.maxSnoozeCount === 'forever' ? Infinity : parseInt(alarm.maxSnoozeCount);

    if (snoozeCount >= maxSnoozes) {
      alert('Maximum snooze count reached');
      return;
    }

    audioService.stopSound();
    Vibration.cancel();

    const snoozeDuration = parseInt(alarm.snooze);
    const snoozeNotificationId = await scheduleSnoozeNotification(alarm, snoozeDuration);
    const snoozeData = await addSnooze(alarm.id, snoozeDuration, snoozeNotificationId);

    setSnoozeCount(snoozeData.snoozeCount);
    router.replace('/');
  };

  const handleDismiss = async () => {
    if (!alarm) return;

    if (alarm.requireTicTacToe) {
      router.push({
        pathname: '/tictactoe',
        params: { alarmId: alarm.id }
      });
    } else {
      dismissAlarm();
    }
  };

  const dismissAlarm = async () => {
    if (!alarm) return;

    audioService.stopSound();
    Vibration.cancel();

    await clearSnoozeForAlarm(alarm.id);

    if (alarm.days.length === 0) {
      await updateAlarm(alarm.id, { isActive: false });
    }

    router.replace('/');
  };

  if (!alarm) {
    return null;
  }

  const formatTime = (hour: number, minute: number, period: 'AM' | 'PM') => {
    const hourStr = hour.toString();
    const minuteStr = minute.toString().padStart(2, '0');
    return `${hourStr}:${minuteStr} ${period}`;
  };

  const maxSnoozes = alarm.maxSnoozeCount === 'forever' ? '∞' : alarm.maxSnoozeCount;
  const canSnooze = alarm.maxSnoozeCount === 'forever' || snoozeCount < parseInt(alarm.maxSnoozeCount);

  return (
    <SafeAreaView style={[styles.container, { backgroundColor: colors.primary }]}>
      <View style={styles.content}>
        <View style={styles.iconContainer}>
          <Ionicons name="alarm" size={100} color={colors.primaryForeground} />
        </View>

        <Text style={[styles.time, { color: colors.primaryForeground }]}>
          {formatTime(alarm.hour, alarm.minute, alarm.period)}
        </Text>

        <Text style={[styles.label, { color: colors.primaryForeground }]}>
          {alarm.label || 'Alarm'}
        </Text>

        {alarm.requireTicTacToe && (
          <View style={[styles.badge, { backgroundColor: 'rgba(255,255,255,0.2)' }]}>
            <Text style={[styles.badgeText, { color: colors.primaryForeground }]}>
              Tic-Tac-Toe required to dismiss
            </Text>
          </View>
        )}

        <View style={styles.snoozeInfo}>
          <Text style={[styles.snoozeText, { color: colors.primaryForeground }]}>
            Snoozed: {snoozeCount} / {maxSnoozes}
          </Text>
        </View>
      </View>

      <View style={styles.actions}>
        {canSnooze && (
          <TouchableOpacity
            onPress={handleSnooze}
            activeOpacity={0.7}
            style={[
              styles.snoozeButton,
              { 
                backgroundColor: 'rgba(255,255,255,0.2)',
                borderColor: 'rgba(255,255,255,0.3)',
              }
            ]}
            testID="button-snooze"
          >
            <Animated.View
              style={[
                styles.snoozeProgress,
                {
                  backgroundColor: colors.primaryForeground,
                },
                useAnimatedStyle(() => ({
                  width: `${progress.value * 100}%`,
                })),
              ]}
            />
            <Text style={[styles.snoozeText, { color: colors.primaryForeground }]}>
              Snooze ({alarm.snooze} min)
            </Text>
          </TouchableOpacity>
        )}
        <Button
          title={alarm.requireTicTacToe ? 'Play Tic-Tac-Toe' : 'Dismiss'}
          onPress={handleDismiss}
          variant="secondary"
          size="lg"
          style={styles.button}
          testID="button-dismiss"
        />
      </View>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    padding: spacing.xl,
  },
  content: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    gap: spacing.lg,
  },
  iconContainer: {
    marginBottom: spacing.lg,
  },
  time: {
    fontSize: 64,
    fontWeight: fontWeight.bold,
  },
  label: {
    fontSize: fontSize.xxl,
    fontWeight: fontWeight.semibold,
  },
  badge: {
    paddingHorizontal: spacing.md,
    paddingVertical: spacing.sm,
    borderRadius: 20,
    marginTop: spacing.md,
  },
  badgeText: {
    fontSize: fontSize.sm,
    fontWeight: fontWeight.medium,
  },
  snoozeInfo: {
    marginTop: spacing.md,
  },
  snoozeText: {
    fontSize: fontSize.base,
  },
  actions: {
    gap: spacing.md,
  },
  button: {
    width: '100%',
  },
  snoozeButton: {
    width: '100%',
    height: 52,
    borderRadius: 8,
    borderWidth: 1,
    overflow: 'hidden',
    justifyContent: 'center',
    alignItems: 'center',
    position: 'relative',
  },
  snoozeProgress: {
    position: 'absolute',
    left: 0,
    top: 0,
    bottom: 0,
    borderRadius: 8,
  },
  snoozeText: {
    fontSize: fontSize.lg,
    fontWeight: fontWeight.semibold,
    zIndex: 1,
  },
});