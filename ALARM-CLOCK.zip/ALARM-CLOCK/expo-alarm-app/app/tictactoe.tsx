import { useState, useEffect } from 'react';
import { View, Text, StyleSheet, TouchableOpacity, Pressable, Vibration } from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import { useRouter, useLocalSearchParams } from 'expo-router';
import { Ionicons } from '@expo/vector-icons';
import { useTheme } from '@/contexts/ThemeContext';
import { getSettings } from '@/lib/settingsService';
import { getAlarmById, updateAlarm } from '@/lib/alarmService';
import { audioService } from '@/lib/audioService';
import { clearSnoozeForAlarm } from '@/lib/snoozeService';
import Button from '@/components/Button';
import { spacing, fontSize, fontWeight, borderRadius } from '@/styles/theme';

type Player = 'X' | 'O' | null;
type Board = Player[];

export default function TicTacToeScreen() {
  const { colors } = useTheme();
  const router = useRouter();
  const params = useLocalSearchParams();
  const [board, setBoard] = useState<Board>(Array(9).fill(null));
  const [isPlayerTurn, setIsPlayerTurn] = useState(true);
  const [winner, setWinner] = useState<Player | 'draw' | null>(null);
  const [winningLine, setWinningLine] = useState<number[]>([]);
  const [difficulty, setDifficulty] = useState<'easy' | 'medium' | 'hard'>('medium');

  useEffect(() => {
    loadSettings();
  }, []);

  useEffect(() => {
    if (!isPlayerTurn && !winner) {
      setTimeout(() => {
        makeAIMove();
      }, 500);
    }
  }, [isPlayerTurn, winner]);

  const loadSettings = async () => {
    const settings = await getSettings();
    setDifficulty(settings.ticTacToeDifficulty);
  };

  const winPatterns = [
    [0, 1, 2], [3, 4, 5], [6, 7, 8],
    [0, 3, 6], [1, 4, 7], [2, 5, 8],
    [0, 4, 8], [2, 4, 6]
  ];

  const checkWinner = (currentBoard: Board): { winner: Player | 'draw' | null; line: number[] } => {
    for (const pattern of winPatterns) {
      const [a, b, c] = pattern;
      if (
        currentBoard[a] &&
        currentBoard[a] === currentBoard[b] &&
        currentBoard[a] === currentBoard[c]
      ) {
        return { winner: currentBoard[a], line: pattern };
      }
    }

    if (currentBoard.every((cell) => cell !== null)) {
      return { winner: 'draw', line: [] };
    }

    return { winner: null, line: [] };
  };

  const minimax = (board: Board, depth: number, isMaximizing: boolean): number => {
    const result = checkWinner(board);
    if (result.winner === 'O') return 10 - depth;
    if (result.winner === 'X') return depth - 10;
    if (result.winner === 'draw') return 0;

    if (isMaximizing) {
      let bestScore = -Infinity;
      for (let i = 0; i < 9; i++) {
        if (board[i] === null) {
          board[i] = 'O';
          const score = minimax(board, depth + 1, false);
          board[i] = null;
          bestScore = Math.max(score, bestScore);
        }
      }
      return bestScore;
    } else {
      let bestScore = Infinity;
      for (let i = 0; i < 9; i++) {
        if (board[i] === null) {
          board[i] = 'X';
          const score = minimax(board, depth + 1, true);
          board[i] = null;
          bestScore = Math.min(score, bestScore);
        }
      }
      return bestScore;
    }
  };

  const getAIMove = (currentBoard: Board): number => {
    const emptySpots = currentBoard
      .map((cell, index) => (cell === null ? index : null))
      .filter((index) => index !== null) as number[];

    if (emptySpots.length === 0) return -1;

    if (difficulty === 'easy') {
      return emptySpots[Math.floor(Math.random() * emptySpots.length)];
    }

    if (difficulty === 'medium' && Math.random() < 0.5) {
      return emptySpots[Math.floor(Math.random() * emptySpots.length)];
    }

    let bestScore = -Infinity;
    let bestMove = -1;

    for (let i = 0; i < 9; i++) {
      if (currentBoard[i] === null) {
        currentBoard[i] = 'O';
        const score = minimax(currentBoard, 0, false);
        currentBoard[i] = null;
        if (score > bestScore) {
          bestScore = score;
          bestMove = i;
        }
      }
    }

    return bestMove !== -1 ? bestMove : emptySpots[0];
  };

  const makeAIMove = () => {
    const aiMove = getAIMove([...board]);
    if (aiMove !== -1) {
      handleCellClick(aiMove, true);
    }
  };

  const handleCellClick = (index: number, isAI: boolean = false) => {
    if (board[index] || winner || (!isAI && !isPlayerTurn)) return;

    const newBoard = [...board];
    newBoard[index] = isPlayerTurn ? 'X' : 'O';
    setBoard(newBoard);

    const result = checkWinner(newBoard);
    if (result.winner) {
      setWinner(result.winner);
      setWinningLine(result.line);
    } else {
      setIsPlayerTurn(!isPlayerTurn);
    }
  };

  const handleComplete = async () => {
    // Stop sound and vibration
    audioService.stopSound();
    Vibration.cancel();

    // If we have an alarm ID, properly dismiss it
    if (params.alarmId) {
      const alarmId = params.alarmId as string;
      
      // Clear snooze data
      await clearSnoozeForAlarm(alarmId);
      
      // Get alarm to check if it's one-time
      const alarm = await getAlarmById(alarmId);
      
      // If one-time alarm (no recurring days), disable it
      if (alarm && alarm.days.length === 0) {
        await updateAlarm(alarmId, { isActive: false });
      }
    }
    
    router.replace('/');
  };

  const resetGame = () => {
    setBoard(Array(9).fill(null));
    setIsPlayerTurn(true);
    setWinner(null);
    setWinningLine([]);
  };

  const renderCell = (index: number) => {
    const value = board[index];
    const isWinning = winningLine.includes(index);

    return (
      <Pressable
        key={index}
        onPress={() => handleCellClick(index)}
        style={[
          styles.cell,
          {
            backgroundColor: isWinning ? colors.success : colors.card,
            borderColor: colors.border,
          },
        ]}
        testID={`cell-${index}`}
      >
        {value === 'X' && (
          <Ionicons name="close" size={60} color={colors.primary} />
        )}
        {value === 'O' && (
          <Ionicons name="radio-button-off" size={60} color={colors.destructive} />
        )}
      </Pressable>
    );
  };

  return (
    <SafeAreaView style={[styles.container, { backgroundColor: colors.background }]}>
      <View style={styles.header}>
        <Text style={[styles.title, { color: colors.text }]}>Tic-Tac-Toe</Text>
        <Text style={[styles.subtitle, { color: colors.textSecondary }]}>
          Win the game to dismiss the alarm
        </Text>
      </View>

      <View style={styles.content}>
        <View style={styles.board}>
          {board.map((_, index) => renderCell(index))}
        </View>

        <View style={styles.status}>
          {!winner && (
            <Text style={[styles.statusText, { color: colors.text }]}>
              {isPlayerTurn ? "Your turn (X)" : "AI's turn (O)"}
            </Text>
          )}
          {winner && winner !== 'draw' && (
            <Text style={[styles.statusText, { color: winner === 'X' ? colors.success : colors.destructive }]}>
              {winner === 'X' ? 'You won!' : 'AI won!'}
            </Text>
          )}
          {winner === 'draw' && (
            <Text style={[styles.statusText, { color: colors.warning }]}>
              It's a draw!
            </Text>
          )}
        </View>
      </View>

      <View style={styles.actions}>
        {winner === 'X' || winner === 'draw' ? (
          <Button
            title="Dismiss Alarm"
            onPress={handleComplete}
            size="lg"
            testID="button-complete"
          />
        ) : (
          <Button
            title="Reset Game"
            onPress={resetGame}
            variant="outline"
            size="lg"
            testID="button-reset"
          />
        )}
      </View>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    padding: spacing.xl,
  },
  header: {
    alignItems: 'center',
    marginBottom: spacing.xl,
  },
  title: {
    fontSize: fontSize.xxxl,
    fontWeight: fontWeight.bold,
  },
  subtitle: {
    fontSize: fontSize.base,
    marginTop: spacing.xs,
  },
  content: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
  },
  board: {
    width: 300,
    height: 300,
    flexDirection: 'row',
    flexWrap: 'wrap',
    gap: 8,
  },
  cell: {
    width: 92,
    height: 92,
    justifyContent: 'center',
    alignItems: 'center',
    borderRadius: borderRadius.lg,
    borderWidth: 2,
  },
  status: {
    marginTop: spacing.xl,
  },
  statusText: {
    fontSize: fontSize.xl,
    fontWeight: fontWeight.semibold,
    textAlign: 'center',
  },
  actions: {
    marginTop: spacing.xl,
  },
});
