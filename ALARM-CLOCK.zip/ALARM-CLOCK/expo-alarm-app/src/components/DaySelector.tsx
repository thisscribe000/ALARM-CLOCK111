import { View, StyleSheet } from 'react-native';
import { DAYS_OF_WEEK, DayOfWeek } from '@/types';
import Badge from './Badge';
import { spacing } from '@/styles/theme';

interface DaySelectorProps {
  selectedDays: string[];
  onToggleDay: (day: string) => void;
  testID?: string;
}

export default function DaySelector({ selectedDays, onToggleDay, testID }: DaySelectorProps) {
  return (
    <View style={styles.container} testID={testID}>
      {DAYS_OF_WEEK.map((day) => (
        <Badge
          key={day}
          label={day}
          selected={selectedDays.includes(day)}
          onPress={() => onToggleDay(day)}
          testID={`badge-day-${day.toLowerCase()}`}
        />
      ))}
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flexDirection: 'row',
    flexWrap: 'wrap',
    gap: spacing.sm,
  },
});
