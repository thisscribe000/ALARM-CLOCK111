import { Switch as RNSwitch, Platform } from 'react-native';
import { useTheme } from '@/contexts/ThemeContext';

interface SwitchProps {
  value: boolean;
  onValueChange: (value: boolean) => void;
  testID?: string;
}

export default function Switch({ value, onValueChange, testID }: SwitchProps) {
  const { colors } = useTheme();

  return (
    <RNSwitch
      value={value}
      onValueChange={onValueChange}
      trackColor={{ false: colors.muted, true: colors.primary }}
      thumbColor={Platform.OS === 'ios' ? colors.card : value ? colors.primaryForeground : colors.card}
      ios_backgroundColor={colors.muted}
      testID={testID}
    />
  );
}
