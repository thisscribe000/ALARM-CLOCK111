import { useState, useEffect, useRef } from 'react';
import { View, Text, StyleSheet, ScrollView, TouchableOpacity, FlatList } from 'react-native';
import { useTheme } from '@/contexts/ThemeContext';
import { spacing, fontSize, fontWeight, borderRadius } from '@/styles/theme';

interface TimePickerProps {
  hour: number;
  minute: number;
  period: 'AM' | 'PM';
  onChange: (hour: number, minute: number, period: 'AM' | 'PM') => void;
  use24Hour?: boolean;
  testID?: string;
}

const ITEM_HEIGHT = 40;

export default function TimePicker({ hour, minute, period, onChange, use24Hour = false, testID }: TimePickerProps) {
  const { colors } = useTheme();
  const hourListRef = useRef<FlatList>(null);
  const minuteListRef = useRef<FlatList>(null);
  const periodListRef = useRef<FlatList>(null);

  // Create extended arrays for infinite scroll effect
  const baseHours = Array.from({ length: 12 }, (_, i) => i + 1);
  const baseMinutes = Array.from({ length: 60 }, (_, i) => i);

  // Repeat arrays 3 times for circular effect
  const hours = [...baseHours, ...baseHours, ...baseHours];
  const minutes = [...baseMinutes, ...baseMinutes, ...baseMinutes];
  const periods: ('AM' | 'PM')[] = ['AM', 'PM'];

  const renderPickerItem = (value: number, isSelected: boolean, formatter?: (v: number) => string) => {
    const displayValue = formatter ? formatter(value) : value.toString();
    return (
      <Text
        style={[
          styles.pickerItem,
          {
            color: isSelected ? colors.text : colors.textTertiary,
            fontSize: isSelected ? fontSize.xxxl : fontSize.xl,
          },
        ]}
      >
        {displayValue}
      </Text>
    );
  };

  const displayHour = use24Hour
    ? (period === 'PM' && hour !== 12 ? hour + 12 : (period === 'AM' && hour === 12 ? 0 : hour))
    : hour;

  useEffect(() => {
    setTimeout(() => {
      // Start in the middle set for infinite scroll
      hourListRef.current?.scrollToIndex({
        index: 12 + (hour - 1),
        animated: false,
      });
      minuteListRef.current?.scrollToIndex({
        index: 60 + minute,
        animated: false,
      });
      periodListRef.current?.scrollToIndex({
        index: period === 'AM' ? 0 : 1,
        animated: false,
      });
    }, 100);
  }, []);

  const handleHourChange = (index: number) => {
    const actualIndex = index % 12;
    onChange(baseHours[actualIndex], minute, period);
  };

  const handleMinuteChange = (index: number) => {
    const actualIndex = index % 60;
    onChange(hour, baseMinutes[actualIndex], period);
  };

  const handlePeriodChange = (index: number) => {
    const newPeriod = periods[index];
    onChange(hour, minute, newPeriod);
  };

  const handleHourScrollEnd = (event: any) => {
    const index = Math.round(event.nativeEvent.contentOffset.y / ITEM_HEIGHT);
    const actualIndex = index % 12;

    // If we're in first or last set, jump to middle set
    if (index < 12) {
      hourListRef.current?.scrollToIndex({
        index: 12 + actualIndex,
        animated: false,
      });
    } else if (index >= 24) {
      hourListRef.current?.scrollToIndex({
        index: 12 + actualIndex,
        animated: false,
      });
    }
    handleHourChange(index);
  };

  const handleMinuteScrollEnd = (event: any) => {
    const index = Math.round(event.nativeEvent.contentOffset.y / ITEM_HEIGHT);
    const actualIndex = index % 60;

    // If we're in first or last set, jump to middle set
    if (index < 60) {
      minuteListRef.current?.scrollToIndex({
        index: 60 + actualIndex,
        animated: false,
      });
    } else if (index >= 120) {
      minuteListRef.current?.scrollToIndex({
        index: 60 + actualIndex,
        animated: false,
      });
    }
    handleMinuteChange(index);
  };

  const handlePeriodScrollEnd = (event: any) => {
    const index = Math.round(event.nativeEvent.contentOffset.y / ITEM_HEIGHT);
    handlePeriodChange(index);
  };

  const renderHourItem = ({ item, index }: { item: number; index: number }) => (
    <TouchableOpacity
      onPress={() => handleHourChange(index)}
      activeOpacity={0.7}
      style={styles.pickerItemContainer}
    >
      {renderPickerItem(item, item === hour)}
    </TouchableOpacity>
  );

  const renderMinuteItem = ({ item, index }: { item: number; index: number }) => (
    <TouchableOpacity
      onPress={() => handleMinuteChange(index)}
      activeOpacity={0.7}
      style={styles.pickerItemContainer}
    >
      {renderPickerItem(item, item === minute, (v) => v.toString().padStart(2, '0'))}
    </TouchableOpacity>
  );

  const renderPeriodItem = ({ item, index }: { item: 'AM' | 'PM'; index: number }) => (
    <TouchableOpacity
      onPress={() => handlePeriodChange(index)}
      activeOpacity={0.7}
      style={styles.pickerItemContainer}
    >
      {renderPickerItem(index, item === period)}
    </TouchableOpacity>
  );

  const viewabilityConfig = {
    itemVisiblePercentThreshold: 50,
  };

  const getItemLayout = (_: any, index: number) => ({
    length: ITEM_HEIGHT,
    offset: ITEM_HEIGHT * index,
    index,
  });


  return (
    <View style={styles.container} testID={testID}>
      <View style={styles.pickerColumn}>
        <FlatList
          ref={hourListRef}
          data={hours}
          keyExtractor={(_, index) => `hour-${index}`}
          renderItem={renderHourItem}
          showsVerticalScrollIndicator={false}
          snapToInterval={ITEM_HEIGHT}
          decelerationRate="fast"
          viewabilityConfig={viewabilityConfig}
          getItemLayout={getItemLayout}
          scrollEnabled={true}
          onMomentumScrollEnd={handleHourScrollEnd}
        />
      </View>

      <Text style={[styles.separator, { color: colors.text }]}>:</Text>

      <View style={styles.pickerColumn}>
        <FlatList
          ref={minuteListRef}
          data={minutes}
          keyExtractor={(_, index) => `minute-${index}`}
          renderItem={renderMinuteItem}
          showsVerticalScrollIndicator={false}
          snapToInterval={ITEM_HEIGHT}
          decelerationRate="fast"
          viewabilityConfig={viewabilityConfig}
          getItemLayout={getItemLayout}
          scrollEnabled={true}
          onMomentumScrollEnd={handleMinuteScrollEnd}
        />
      </View>

      {!use24Hour && (
        <View style={styles.periodContainer}>
          <TouchableOpacity
            onPress={() => onChange(hour, minute, 'AM')}
            style={[
              styles.periodButton,
              {
                backgroundColor: period === 'AM' ? colors.primary : colors.muted,
              },
            ]}
            activeOpacity={0.7}
            testID="button-period-am"
          >
            <Text
              style={[
                styles.periodText,
                {
                  color: period === 'AM' ? colors.primaryForeground : colors.text,
                },
              ]}
            >
              AM
            </Text>
          </TouchableOpacity>
          <TouchableOpacity
            onPress={() => onChange(hour, minute, 'PM')}
            style={[
              styles.periodButton,
              {
                backgroundColor: period === 'PM' ? colors.primary : colors.muted,
              },
            ]}
            activeOpacity={0.7}
            testID="button-period-pm"
          >
            <Text
              style={[
                styles.periodText,
                {
                  color: period === 'PM' ? colors.primaryForeground : colors.text,
                },
              ]}
            >
              PM
            </Text>
          </TouchableOpacity>
        </View>
      )}
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    height: 200,
  },
  pickerColumn: {
    width: 80,
    height: 200,
  },
  pickerItemContainer: {
    height: ITEM_HEIGHT,
    justifyContent: 'center',
    alignItems: 'center',
  },
  pickerItem: {
    textAlign: 'center',
    paddingVertical: spacing.xs,
    fontWeight: fontWeight.semibold,
  },
  separator: {
    fontSize: fontSize.xxxl,
    fontWeight: fontWeight.bold,
    marginHorizontal: spacing.sm,
  },
  periodContainer: {
    marginLeft: spacing.md,
    gap: spacing.sm,
  },
  periodButton: {
    paddingHorizontal: spacing.md,
    paddingVertical: spacing.sm,
    borderRadius: borderRadius.md,
    minWidth: 60,
    alignItems: 'center',
  },
  periodText: {
    fontSize: fontSize.sm,
    fontWeight: fontWeight.semibold,
  },
});