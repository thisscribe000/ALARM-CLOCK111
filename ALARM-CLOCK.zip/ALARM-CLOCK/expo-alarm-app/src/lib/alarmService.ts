import { Alarm } from '@/types';
import { getItem, setItem, STORAGE_KEYS } from './storage';

function generateUUID(): string {
  return 'xxxxxxxx-xxxx-4xxx-yxxx-xxxxxxxxxxxx'.replace(/[xy]/g, (c) => {
    const r = (Math.random() * 16) | 0;
    const v = c === 'x' ? r : (r & 0x3) | 0x8;
    return v.toString(16);
  });
}

export function computeNextTrigger(alarm: Alarm): number {
  if (!alarm.isActive) return 0;

  const now = new Date();
  const dayMap: { [key: string]: number } = {
    Sun: 0,
    Mon: 1,
    Tues: 2,
    Wed: 3,
    Thur: 4,
    Fri: 5,
    Sat: 6,
  };

  let hours = alarm.hour;
  if (alarm.period === 'PM' && hours !== 12) hours += 12;
  if (alarm.period === 'AM' && hours === 12) hours = 0;

  if (alarm.days.length === 0) {
    const trigger = new Date(now);
    trigger.setHours(hours, alarm.minute, 0, 0);
    
    if (trigger.getTime() <= now.getTime()) {
      trigger.setDate(trigger.getDate() + 1);
    }
    
    return trigger.getTime();
  }

  const currentDay = now.getDay();
  let daysUntilNext = Infinity;

  for (const day of alarm.days) {
    const targetDay = dayMap[day];
    let diff = targetDay - currentDay;

    if (diff < 0) {
      diff += 7;
    } else if (diff === 0) {
      const todayAlarmTime = new Date(now);
      todayAlarmTime.setHours(hours, alarm.minute, 0, 0);
      
      if (todayAlarmTime.getTime() <= now.getTime()) {
        diff = 7;
      }
    }

    if (diff < daysUntilNext) {
      daysUntilNext = diff;
    }
  }

  if (daysUntilNext === Infinity) {
    return 0;
  }

  const trigger = new Date(now);
  trigger.setDate(trigger.getDate() + daysUntilNext);
  trigger.setHours(hours, alarm.minute, 0, 0);

  return trigger.getTime();
}

export async function getAlarms(): Promise<Alarm[]> {
  const alarms = await getItem<Alarm[]>(STORAGE_KEYS.ALARMS);
  if (!alarms) return [];
  
  return alarms.map((alarm) => ({
    ...alarm,
    nextTrigger: computeNextTrigger(alarm),
  }));
}

export async function getAlarmById(id: string): Promise<Alarm | null> {
  const alarms = await getAlarms();
  return alarms.find((a) => a.id === id) || null;
}

export async function saveAlarm(alarm: Omit<Alarm, 'id'>): Promise<Alarm> {
  const newAlarm: Alarm = {
    ...alarm,
    id: generateUUID(),
    nextTrigger: computeNextTrigger(alarm as Alarm),
  };

  const alarms = await getAlarms();
  alarms.push(newAlarm);
  await setItem(STORAGE_KEYS.ALARMS, alarms);
  return newAlarm;
}

export async function updateAlarm(id: string, data: Partial<Alarm>): Promise<Alarm | null> {
  const alarms = await getAlarms();
  const index = alarms.findIndex((a) => a.id === id);

  if (index === -1) return null;

  const updatedAlarm: Alarm = {
    ...alarms[index],
    ...data,
    nextTrigger: computeNextTrigger({ ...alarms[index], ...data }),
  };

  alarms[index] = updatedAlarm;
  await setItem(STORAGE_KEYS.ALARMS, alarms);
  return updatedAlarm;
}

export async function deleteAlarm(id: string): Promise<boolean> {
  const alarms = await getAlarms();
  const filtered = alarms.filter((a) => a.id !== id);

  if (filtered.length === alarms.length) return false;

  await setItem(STORAGE_KEYS.ALARMS, filtered);
  return true;
}

export async function toggleAlarm(id: string): Promise<Alarm | null> {
  const alarms = await getAlarms();
  const alarm = alarms.find((a) => a.id === id);

  if (!alarm) return null;

  return updateAlarm(id, { isActive: !alarm.isActive });
}
