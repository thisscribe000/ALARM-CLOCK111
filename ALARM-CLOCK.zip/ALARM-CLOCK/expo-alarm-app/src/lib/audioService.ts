import { Audio } from 'expo-av';
import * as Haptics from 'expo-haptics';
import { Asset } from 'expo-asset';

class AudioService {
  private sound: Audio.Sound | null = null;
  private isPlaying: boolean = false;

  async playSound(soundKey: string, customSoundUrl?: string): Promise<void> {
    try {
      await this.stopSound();
      await Audio.setAudioModeAsync({
        allowsRecordingIOS: false,
        playsInSilentModeIOS: true,
        staysActiveInBackground: true,
        shouldDuckAndroid: true,
      });

      let soundUri: string;

      if (soundKey === 'custom' && customSoundUrl) {
        soundUri = customSoundUrl;
      } else {
        const soundMap: { [key: string]: any } = {
          default: require('../../assets/sounds/default-alarm.mp3'),
          gentle: require('../../assets/sounds/gentle-wake.mp3'),
          loud: require('../../assets/sounds/loud-alarm.mp3'),
          birdsong: require('../../assets/sounds/birdsong.mp3'),
          chimes: require('../../assets/sounds/chimes.mp3'),
        };

        const asset = Asset.fromModule(soundMap[soundKey] || soundMap.default);
        await asset.downloadAsync();
        soundUri = asset.localUri || asset.uri;
      }

      const { sound } = await Audio.Sound.createAsync(
        { uri: soundUri },
        { shouldPlay: true, isLooping: true, volume: 1.0 }
      );

      this.sound = sound;
      this.isPlaying = true;

      await Haptics.notificationAsync(Haptics.NotificationFeedbackType.Warning);
    } catch (error) {
      console.error('Error playing sound:', error);
    }
  }

  async stopSound(): Promise<void> {
    if (this.sound) {
      try {
        await this.sound.stopAsync();
        await this.sound.unloadAsync();
        this.sound = null;
        this.isPlaying = false;
      } catch (error) {
        console.error('Error stopping sound:', error);
      }
    }
  }

  async vibrate(): Promise<void> {
    await Haptics.notificationAsync(Haptics.NotificationFeedbackType.Warning);
  }

  getIsPlaying(): boolean {
    return this.isPlaying;
  }
}

export const audioService = new AudioService();
