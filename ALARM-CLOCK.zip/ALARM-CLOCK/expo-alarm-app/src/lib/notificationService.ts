import * as Notifications from 'expo-notifications';
import { Platform } from 'react-native';
import { Alarm } from '@/types';

export async function requestPermissions(): Promise<boolean> {
  const { status: existingStatus } = await Notifications.getPermissionsAsync();
  let finalStatus = existingStatus;
  
  if (existingStatus !== 'granted') {
    const { status } = await Notifications.requestPermissionsAsync();
    finalStatus = status;
  }
  
  return finalStatus === 'granted';
}

export async function registerNotificationHandler(): Promise<void> {
  if (Platform.OS === 'android') {
    await Notifications.setNotificationChannelAsync('alarms', {
      name: 'Alarms',
      importance: Notifications.AndroidImportance.MAX,
      sound: 'default',
      vibrationPattern: [0, 250, 250, 250],
      lightColor: '#FF231F7C',
      enableVibrate: true,
      enableLights: true,
      lockscreenVisibility: Notifications.AndroidNotificationVisibility.PUBLIC,
      bypassDnd: true,
    });
  }
}

export async function scheduleAlarmNotification(alarm: Alarm): Promise<string> {
  const hour24 = alarm.period === 'PM' && alarm.hour !== 12 
    ? alarm.hour + 12 
    : alarm.period === 'AM' && alarm.hour === 12 
    ? 0 
    : alarm.hour;

  if (alarm.days.length === 0) {
    const trigger = new Date(alarm.nextTrigger || 0);
    const notificationId = await Notifications.scheduleNotificationAsync({
      content: {
        title: alarm.label || 'Alarm',
        body: 'Time to wake up!',
        sound: 'default',
        priority: Notifications.AndroidNotificationPriority.MAX,
        vibrate: [0, 250, 250, 250],
        data: { alarmId: alarm.id },
      },
      trigger,
    });
    return notificationId;
  } else {
    const dayMap: { [key: string]: number } = {
      Sun: 1,
      Mon: 2,
      Tues: 3,
      Wed: 4,
      Thur: 5,
      Fri: 6,
      Sat: 7,
    };

    const notificationIds: string[] = [];

    for (const day of alarm.days) {
      const weekday = dayMap[day];
      const notificationId = await Notifications.scheduleNotificationAsync({
        content: {
          title: alarm.label || 'Alarm',
          body: 'Time to wake up!',
          sound: 'default',
          priority: Notifications.AndroidNotificationPriority.MAX,
          vibrate: [0, 250, 250, 250],
          data: { alarmId: alarm.id },
        },
        trigger: {
          hour: hour24,
          minute: alarm.minute,
          repeats: true,
          weekday,
        },
      });
      notificationIds.push(notificationId);
    }

    return notificationIds.join(',');
  }
}

export async function cancelAlarmNotification(notificationId: string): Promise<void> {
  await Notifications.cancelScheduledNotificationAsync(notificationId);
}

export async function cancelAllNotifications(): Promise<void> {
  await Notifications.cancelAllScheduledNotificationsAsync();
}

export async function getAllScheduledNotifications() {
  return await Notifications.getAllScheduledNotificationsAsync();
}
