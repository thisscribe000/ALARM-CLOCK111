import { Settings } from '@/types';
import { getItem, setItem, STORAGE_KEYS } from './storage';

const defaultSettings: Settings = {
  theme: 'system',
  ticTacToeDifficulty: 'medium',
  alarmSoundOption: 'default',
  use24HourTime: 'system',
};

export async function getSettings(): Promise<Settings> {
  const settings = await getItem<Settings>(STORAGE_KEYS.SETTINGS);
  return settings ? { ...defaultSettings, ...settings } : defaultSettings;
}

export async function updateSettings(updates: Partial<Settings>): Promise<Settings> {
  const current = await getSettings();
  const updated = { ...current, ...updates };
  await setItem(STORAGE_KEYS.SETTINGS, updated);
  return updated;
}

export async function resetSettings(): Promise<Settings> {
  await setItem(STORAGE_KEYS.SETTINGS, defaultSettings);
  return defaultSettings;
}
