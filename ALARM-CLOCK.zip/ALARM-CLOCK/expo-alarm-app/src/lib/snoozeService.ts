import * as Notifications from 'expo-notifications';
import { Alarm, SnoozeData } from '@/types';
import { getItem, setItem, STORAGE_KEYS } from './storage';

export async function getSnoozeData(): Promise<SnoozeData[]> {
  const data = await getItem<SnoozeData[]>(STORAGE_KEYS.SNOOZE_DATA);
  return data || [];
}

export async function setSnoozeData(data: SnoozeData[]): Promise<void> {
  await setItem(STORAGE_KEYS.SNOOZE_DATA, data);
}

export async function addSnooze(
  alarmId: string, 
  snoozeDuration: number,
  snoozeNotificationId?: string
): Promise<SnoozeData> {
  const allSnoozeData = await getSnoozeData();
  const existing = allSnoozeData.find((s) => s.alarmId === alarmId);

  if (existing?.snoozeNotificationId) {
    await cancelSnoozeNotification(existing.snoozeNotificationId);
  }

  const now = Date.now();
  const wakeUpTime = now + snoozeDuration * 60 * 1000;

  const snoozeData: SnoozeData = {
    alarmId,
    snoozeCount: existing ? existing.snoozeCount + 1 : 1,
    snoozedAt: now,
    wakeUpTime,
    snoozeNotificationId,
  };

  const updated = allSnoozeData.filter((s) => s.alarmId !== alarmId);
  updated.push(snoozeData);

  await setSnoozeData(updated);
  return snoozeData;
}

export async function cancelSnoozeNotification(snoozeNotificationId: string): Promise<void> {
  await Notifications.cancelScheduledNotificationAsync(snoozeNotificationId);
}

export async function getSnoozeForAlarm(alarmId: string): Promise<SnoozeData | null> {
  const allSnoozeData = await getSnoozeData();
  return allSnoozeData.find((s) => s.alarmId === alarmId) || null;
}

export async function clearSnoozeForAlarm(alarmId: string): Promise<void> {
  const allSnoozeData = await getSnoozeData();
  const snooze = allSnoozeData.find((s) => s.alarmId === alarmId);
  
  if (snooze?.snoozeNotificationId) {
    await cancelSnoozeNotification(snooze.snoozeNotificationId);
  }
  
  const updated = allSnoozeData.filter((s) => s.alarmId !== alarmId);
  await setSnoozeData(updated);
}

export async function scheduleSnoozeNotification(
  alarm: Alarm,
  snoozeDuration: number
): Promise<string> {
  const trigger = new Date(Date.now() + snoozeDuration * 60 * 1000);

  const notificationId = await Notifications.scheduleNotificationAsync({
    content: {
      title: alarm.label || 'Alarm',
      body: 'Snooze ended - Time to wake up!',
      sound: 'default',
      priority: Notifications.AndroidNotificationPriority.MAX,
      vibrate: [0, 250, 250, 250],
      data: { alarmId: alarm.id, isSnoozed: true },
    },
    trigger,
  });

  return notificationId;
}
