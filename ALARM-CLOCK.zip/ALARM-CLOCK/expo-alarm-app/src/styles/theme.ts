export const colors = {
  light: {
    background: '#F5F5F5',
    card: '#FFFFFF',
    cardBorder: '#E5E7EB',
    primary: '#36454F',
    primaryForeground: '#FFFFFF',
    text: '#1F2937',
    textSecondary: '#6B7280',
    textTertiary: '#9CA3AF',
    border: '#E5E7EB',
    inputBorder: '#D1D5DB',
    destructive: '#EF4444',
    destructiveForeground: '#FFFFFF',
    success: '#10B981',
    warning: '#F59E0B',
    muted: '#F3F4F6',
    mutedForeground: '#6B7280',
    accent: '#3B82F6',
    accentForeground: '#FFFFFF',
  },
  dark: {
    background: '#111827',
    card: '#1F2937',
    cardBorder: '#374151',
    primary: '#60A5FA',
    primaryForeground: '#1F2937',
    text: '#F9FAFB',
    textSecondary: '#D1D5DB',
    textTertiary: '#9CA3AF',
    border: '#374151',
    inputBorder: '#4B5563',
    destructive: '#EF4444',
    destructiveForeground: '#FFFFFF',
    success: '#10B981',
    warning: '#F59E0B',
    muted: '#374151',
    mutedForeground: '#9CA3AF',
    accent: '#3B82F6',
    accentForeground: '#FFFFFF',
  },
};

export const spacing = {
  xs: 4,
  sm: 8,
  md: 16,
  lg: 24,
  xl: 32,
  xxl: 48,
};

export const borderRadius = {
  sm: 4,
  md: 8,
  lg: 12,
  xl: 16,
  full: 9999,
};

export const fontSize = {
  xs: 12,
  sm: 14,
  base: 16,
  lg: 18,
  xl: 20,
  xxl: 24,
  xxxl: 28,
};

export const fontWeight = {
  normal: '400' as const,
  medium: '500' as const,
  semibold: '600' as const,
  bold: '700' as const,
};
