export interface Alarm {
  id: string;
  label: string;
  hour: number;
  minute: number;
  period: 'AM' | 'PM';
  days: string[];
  isActive: boolean;
  sound: string;
  snooze: string;
  maxSnoozeCount: string;
  requireTicTacToe: boolean;
  nextTrigger?: number;
  notificationId?: string;
}

export interface Settings {
  theme: 'light' | 'dark' | 'system';
  ticTacToeDifficulty: 'easy' | 'medium' | 'hard';
  alarmSoundOption: 'default' | 'choose' | 'custom';
  customSoundUrl?: string;
  use24HourTime: boolean | 'system';
}

export interface SnoozeData {
  alarmId: string;
  snoozeCount: number;
  snoozedAt: number;
  wakeUpTime: number;
  snoozeNotificationId?: string;
}

export type DayOfWeek = 'Sun' | 'Mon' | 'Tues' | 'Wed' | 'Thur' | 'Fri' | 'Sat';

export const DAYS_OF_WEEK: DayOfWeek[] = ['Sun', 'Mon', 'Tues', 'Wed', 'Thur', 'Fri', 'Sat'];
